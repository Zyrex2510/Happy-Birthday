HAPPY BIRTHDAY — source files
=============================

You normally never need this folder.

To change the letter text, the title screen, or the buttons:
  open "Happy Birthday.html" (one folder up) in Notepad
  and edit the CONFIG block right at the top of the file.
  Save, then reopen the file in a browser. That's it.

This folder is only for deeper changes (colors, camera, music, 3D scene):

  src/style.css   - all 2D styling (letter page, title screen, buttons)
  src/audio.js    - the synthesized piano, strings, wind, birds, paper sounds
  src/world.js    - the 3D room, desk, envelope, airplane, butterflies
  src/app.js      - the film: scenes, camera moves, handwriting, timing
  src/body.html   - the page skeleton
  fonts/          - embedded fonts (base64)
  vendor/         - three.js r158

After editing, rebuild the single file with:

  node build.js

(needs Node.js; it overwrites "Happy Birthday.html" in the parent folder)
