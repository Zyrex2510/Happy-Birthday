/* ============================================================
   AUDIO — everything synthesized live. Soft felt piano, a distant
   string, wind through the open window, birds, paper foley.
   ============================================================ */
const AudioSys = (() => {
  let ctx = null;
  let master, dry, revSend, reverb, muted = false;
  let noiseBuf = null;
  let musicOn = false;
  let schedTimer = null;
  let nextBarTime = 0;
  let barIndex = 0;
  const BPM = 63;
  const BEAT = 60 / BPM;          // ~0.952s
  const BAR = BEAT * 4;

  const m2f = (m) => 440 * Math.pow(2, (m - 69) / 12);

  function makeNoise() {
    const len = ctx.sampleRate * 2;
    const buf = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const d = buf.getChannelData(c);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    return buf;
  }

  function makeIR(seconds = 2.9, decay = 3.2) {
    const len = Math.floor(ctx.sampleRate * seconds);
    const buf = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const d = buf.getChannelData(c);
      let last = 0;
      for (let i = 0; i < len; i++) {
        const t = i / len;
        // lowpassed noise tail — warm room, not a cathedral
        const n = (Math.random() * 2 - 1) * Math.pow(1 - t, decay);
        last = last * 0.72 + n * 0.28;
        d[i] = last;
      }
    }
    return buf;
  }

  function init() {
    if (ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.85;
    master.connect(ctx.destination);

    reverb = ctx.createConvolver();
    reverb.buffer = makeIR();
    const revGain = ctx.createGain();
    revGain.gain.value = 0.85;
    reverb.connect(revGain);
    revGain.connect(master);

    dry = ctx.createGain();
    dry.gain.value = 1.0;
    dry.connect(master);

    revSend = ctx.createGain();
    revSend.gain.value = 1.0;
    revSend.connect(reverb);

    noiseBuf = makeNoise();
    startWind();
    scheduleBirdsLoop();
  }

  /* ---------- instruments ---------- */

  function piano(midi, when, vel = 0.4) {
    if (!ctx) return;
    const f = m2f(midi);
    const out = ctx.createGain();
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 900 + vel * 3800;
    lp.Q.value = 0.4;
    out.connect(lp);
    const dg = ctx.createGain(); dg.gain.value = 0.62;
    const rg = ctx.createGain(); rg.gain.value = 0.5;
    lp.connect(dg); dg.connect(dry);
    lp.connect(rg); rg.connect(revSend);

    const decay = Math.min(4.6, Math.max(1.3, 4.6 - (midi - 40) * 0.045));
    const partials = [
      [1.0, 1.0], [2.0015, 0.32], [3.004, 0.09],
    ];
    for (const [ratio, amp] of partials) {
      const o = ctx.createOscillator();
      o.type = ratio < 1.5 ? 'triangle' : 'sine';
      o.frequency.value = f * ratio;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0, when);
      g.gain.linearRampToValueAtTime(vel * 0.55 * amp, when + 0.006);
      g.gain.exponentialRampToValueAtTime(0.00012, when + decay * (ratio < 1.5 ? 1 : 0.55));
      o.connect(g); g.connect(out);
      o.start(when);
      o.stop(when + decay + 0.15);
    }
  }

  function stringPad(midi, when, dur, vol = 0.016) {
    if (!ctx) return;
    const f = m2f(midi);
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.value = 760; lp.Q.value = 0.3;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, when);
    g.gain.linearRampToValueAtTime(vol, when + Math.min(1.6, dur * 0.45));
    g.gain.setValueAtTime(vol, when + dur - 0.9);
    g.gain.linearRampToValueAtTime(0, when + dur);
    lp.connect(g);
    const rg = ctx.createGain(); rg.gain.value = 1.6; g.connect(rg); rg.connect(revSend);
    g.connect(dry);
    for (const det of [-5, 4]) {
      const o = ctx.createOscillator();
      o.type = 'sawtooth';
      o.frequency.value = f;
      o.detune.value = det;
      // slow vibrato
      const lfo = ctx.createOscillator(); lfo.frequency.value = 4.6;
      const lg = ctx.createGain(); lg.gain.value = 3.2;
      lfo.connect(lg); lg.connect(o.detune);
      lfo.start(when); lfo.stop(when + dur + 0.1);
      const og = ctx.createGain(); og.gain.value = 0.5;
      o.connect(og); og.connect(lp);
      o.start(when); o.stop(when + dur + 0.1);
    }
  }

  function celesta(midi, when, vel = 0.25) {
    if (!ctx) return;
    const f = m2f(midi);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, when);
    g.gain.linearRampToValueAtTime(vel, when + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0001, when + 1.7);
    const rg = ctx.createGain(); rg.gain.value = 0.9;
    g.connect(dry); g.connect(rg); rg.connect(revSend);
    for (const [r, a] of [[1, 1], [3.98, 0.24]]) {
      const o = ctx.createOscillator();
      o.type = 'sine'; o.frequency.value = f * r;
      const og = ctx.createGain(); og.gain.value = a * 0.5;
      o.connect(og); og.connect(g);
      o.start(when); o.stop(when + 1.8);
    }
  }

  /* ---------- foley ---------- */

  function noiseHit({ when = 0, dur = 0.12, fc = 2200, q = 1.2, vol = 0.1, type = 'bandpass', rev = 0.3 }) {
    if (!ctx) return;
    const t = when || ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = noiseBuf;
    src.playbackRate.value = 0.9 + Math.random() * 0.25;
    const f = ctx.createBiquadFilter();
    f.type = type; f.frequency.value = fc; f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g);
    g.connect(dry);
    if (rev > 0) { const rg = ctx.createGain(); rg.gain.value = rev; g.connect(rg); rg.connect(revSend); }
    src.start(t, Math.random() * 1.2);
    src.stop(t + dur + 0.05);
  }

  const paper = {
    land() {
      noiseHit({ dur: 0.09, fc: 1500, q: 0.8, vol: 0.09 });
      noiseHit({ dur: 0.16, fc: 320, q: 0.6, vol: 0.05, type: 'lowpass' });
    },
    flap() { noiseHit({ dur: 0.35, fc: 1100, q: 0.7, vol: 0.055 }); },
    slide() { noiseHit({ dur: 0.55, fc: 1900, q: 0.5, vol: 0.04 }); },
    unfold() { noiseHit({ dur: 0.3, fc: 1400, q: 0.7, vol: 0.05 }); setTimeout(() => noiseHit({ dur: 0.18, fc: 2400, q: 0.9, vol: 0.03 }), 140); },
    scratch() { noiseHit({ dur: 0.05, fc: 3800 + Math.random() * 1600, q: 2.2, vol: 0.011, rev: 0.05 }); },
  };

  function sealCrack() {
    if (!ctx) return;
    const t = ctx.currentTime;
    noiseHit({ when: t, dur: 0.05, fc: 3200, q: 2.5, vol: 0.14 });
    noiseHit({ when: t + 0.07, dur: 0.07, fc: 2100, q: 2, vol: 0.11 });
    // low knock body
    const o = ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(210, t);
    o.frequency.exponentialRampToValueAtTime(70, t + 0.14);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.09, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
    o.connect(g); g.connect(dry);
    o.start(t); o.stop(t + 0.2);
  }

  function bloomPluck(step = 0) {
    // gentle harp-ish note from F major pentatonic, ascending with each bloom
    const scale = [65, 67, 69, 72, 74, 77, 79, 81];
    const midi = scale[step % scale.length];
    if (!ctx) return;
    celesta(midi, ctx.currentTime + 0.02, 0.14);
  }

  function magicChime() {
    if (!ctx) return;
    const t = ctx.currentTime + 0.1;
    const run = [77, 81, 84, 89, 93, 96];
    run.forEach((m, i) => celesta(m, t + i * 0.13, 0.2 - i * 0.02));
  }

  /* ---------- ambience ---------- */

  function startWind() {
    const src = ctx.createBufferSource();
    src.buffer = noiseBuf; src.loop = true;
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.value = 420; lp.Q.value = 0.4;
    const g = ctx.createGain(); g.gain.value = 0.0;
    src.connect(lp); lp.connect(g); g.connect(dry);
    src.start();
    // slow breathing swell
    const lfo = ctx.createOscillator(); lfo.frequency.value = 0.09;
    const lg = ctx.createGain(); lg.gain.value = 0.006;
    lfo.connect(lg); lg.connect(g.gain);
    g.gain.value = 0.009;
    lfo.start();
    const lfo2 = ctx.createOscillator(); lfo2.frequency.value = 0.05;
    const lg2 = ctx.createGain(); lg2.gain.value = 120;
    lfo2.connect(lg2); lg2.connect(lp.frequency);
    lfo2.start();
  }

  function birdChirp() {
    if (!ctx || muted) return;
    const t0 = ctx.currentTime + 0.05;
    const pan = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    const outNode = ctx.createGain();
    outNode.gain.value = 1;
    if (pan) { pan.pan.value = Math.random() * 1.4 - 0.7; outNode.connect(pan); pan.connect(revSend); }
    else outNode.connect(revSend);
    const n = 2 + Math.floor(Math.random() * 3);
    for (let i = 0; i < n; i++) {
      const t = t0 + i * (0.11 + Math.random() * 0.06);
      const o = ctx.createOscillator();
      o.type = 'sine';
      const base = 2500 + Math.random() * 900;
      o.frequency.setValueAtTime(base, t);
      o.frequency.exponentialRampToValueAtTime(base * (1.18 + Math.random() * 0.25), t + 0.045);
      o.frequency.exponentialRampToValueAtTime(base * 0.92, t + 0.09);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(0.028, t + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.1);
      o.connect(g); g.connect(outNode);
      o.start(t); o.stop(t + 0.12);
    }
  }

  function scheduleBirdsLoop() {
    const loop = () => {
      birdChirp();
      setTimeout(loop, 9000 + Math.random() * 9000);
    };
    setTimeout(loop, 4000 + Math.random() * 4000);
  }

  /* ---------- music ---------- */
  // F major, gentle. chords as midi sets [bass, ...arpeggio tones]
  const CHORDS = [
    { bass: 41, tones: [53, 57, 60, 65] },  // F
    { bass: 40, tones: [55, 60, 64, 67] },  // C/E
    { bass: 38, tones: [53, 57, 62, 65] },  // Dm7
    { bass: 46, tones: [53, 58, 62, 65] },  // Bbmaj7
    { bass: 45, tones: [53, 57, 60, 65] },  // F/A
    { bass: 46, tones: [53, 58, 62, 67] },  // Bb(add9-ish)
    { bass: 43, tones: [55, 58, 62, 65] },  // Gm7
    { bass: 36, tones: [52, 55, 60, 64] },  // C(E) -> leading home
  ];
  const ARP = [0, 1, 2, 3, 2, 3, 1, 2];
  const ARPV = [0.34, 0.2, 0.26, 0.3, 0.2, 0.24, 0.18, 0.22];
  // sparse melody, phrased across the 8-bar loop (bar, beat, midi, vel)
  const MELODY = [
    [1, 1.5, 69, 0.34], [2, 0.0, 67, 0.3], [2, 2.0, 65, 0.32],
    [3, 1.0, 72, 0.36], [4, 0.0, 74, 0.3], [4, 1.5, 72, 0.26], [4, 2.5, 69, 0.28],
    [5, 1.0, 65, 0.3], [6, 0.5, 67, 0.28], [6, 2.0, 69, 0.32],
    [7, 1.0, 67, 0.26], [7, 2.5, 65, 0.3],
  ];

  function scheduleBar(bar, when) {
    const c = CHORDS[bar % 8];
    const loop = Math.floor(bar / 8);
    // left hand
    piano(c.bass, when + (Math.random() - 0.5) * 0.02, 0.3);
    if (bar % 2 === 1) piano(c.bass + 7, when + BEAT * 2 + (Math.random() - 0.5) * 0.03, 0.16);
    // broken chord
    for (let i = 0; i < 8; i++) {
      if (Math.random() < 0.14 && i > 0) continue; // breathe
      const t = when + i * (BEAT / 2) + (Math.random() - 0.5) * 0.024;
      piano(c.tones[ARP[i]], t, ARPV[i] * (0.85 + Math.random() * 0.3));
    }
    // melody from second loop on
    if (loop >= 1) {
      for (const [b, beat, midi, vel] of MELODY) {
        if (b - 1 === bar % 8) {
          const t = when + beat * BEAT + (Math.random() - 0.5) * 0.02;
          piano(midi, t, vel);
          if (Math.random() < 0.4) piano(midi + 12, t + 0.012, vel * 0.24);
        }
      }
    }
    // whisper of strings from loop 2
    if (loop >= 2 && bar % 2 === 0) {
      stringPad(c.bass + 24, when, BAR * 2 + 0.5, 0.013);
      if (bar % 4 === 0) stringPad(c.bass + 31, when + 0.3, BAR * 2, 0.009);
    }
  }

  function startMusic() {
    if (!ctx || musicOn) return;
    musicOn = true;
    nextBarTime = ctx.currentTime + 0.15;
    barIndex = 0;
    schedTimer = setInterval(() => {
      while (nextBarTime < ctx.currentTime + 1.2) {
        scheduleBar(barIndex, nextBarTime);
        barIndex++;
        nextBarTime += BAR;
      }
    }, 220);
  }

  function finale() {
    // let the loop go, ring a last warm F chord on top
    if (!ctx) return;
    const t = ctx.currentTime + 0.2;
    [41, 53, 57, 60, 65, 69].forEach((m, i) => piano(m, t + i * 0.09, 0.3 - i * 0.02));
    setTimeout(() => {
      if (schedTimer) clearInterval(schedTimer);
      musicOn = false;
    }, 400);
  }

  let ducked = false;
  function level() { return muted ? 0 : (ducked ? 0.34 : 0.85); }
  function setMuted(v) {
    muted = v;
    if (!ctx) return;
    const t = ctx.currentTime;
    master.gain.cancelScheduledValues(t);
    master.gain.setTargetAtTime(level(), t, 0.12);
  }
  // pull the music back under the reading voice
  function duck(on) {
    if (ducked === on) return;
    ducked = on;
    if (!ctx) return;
    const t = ctx.currentTime;
    master.gain.cancelScheduledValues(t);
    master.gain.setTargetAtTime(level(), t, on ? 0.35 : 0.9);
  }

  function resume() { if (ctx && ctx.state === 'suspended') ctx.resume(); }

  return { init, resume, startMusic, finale, piano, paper, sealCrack, bloomPluck, magicChime, setMuted, duck, get muted() { return muted; } };
})();
