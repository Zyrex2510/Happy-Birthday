/* ============================================================
   DIRECTOR — states, camera choreography, handwriting, magic.
   ============================================================ */
(() => {
  const RM = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const $ = (id) => document.getElementById(id);
  window.addEventListener('error', (e) => (window.__errors = window.__errors || []).push(String(e.message)));

  /* ---------- editable text (see the CONFIG block at the top of this file) ---------- */
  const CFG = Object.assign({
    titleEyebrow: 'Something small arrived for you',
    title: 'For You',
    titleSub: 'a birthday letter',
    birthdayDate: '',
    beginButton: 'Begin',
    beginNote: 'sound on, lights low',
    openButton: 'Open the letter',
    headline: 'Happy Birthday!',
    paragraphs: [],
    signature: 'With all my heart',
    fromName: '',
    voice: true,
    voiceLang: 'en-GB',
    voiceName: '',
    voiceRate: 0.76,
    voicePitch: 0.96,
    voiceVolume: 0.7,
    endEyebrow: 'And always remember',
    endTitle: 'Happy Birthday',
    endLine: 'with all my heart',
    replayButton: 'Watch it again',
    creditText: '',
    creditLink: '',
  }, window.CONFIG || {});
  // pour the config into the page
  (() => {
    const put = (id, v) => { const el = $(id); if (el && v != null) el.textContent = v; };
    put('ttlEyebrow', CFG.titleEyebrow);
    put('ttlMain', CFG.title);
    put('ttlSub', CFG.titleSub);
    put('ttlDate', CFG.birthdayDate);
    put('btnBegin', CFG.beginButton);
    put('ttlNote', CFG.beginNote);
    put('btnOpen', CFG.openButton);
    put('endEyebrow', CFG.endEyebrow);
    put('endTitle', CFG.endTitle);
    put('btnReplay', CFG.replayButton);
    const hl = $('endLine');
    if (hl) {
      hl.textContent = CFG.endLine + ' ';
      const h = document.createElement('span');
      h.className = 'heart';
      h.textContent = '❤';
      hl.appendChild(h);
    }
    // credit — only rendered when both a name and a link are given
    const cText = $('creditText'), cLink = $('creditLink');
    if (cText && cLink) {
      if (CFG.creditText && CFG.creditLink) {
        cText.textContent = CFG.creditText;
        cLink.href = CFG.creditLink;
      } else if (CFG.creditText) {
        cText.textContent = CFG.creditText;
        cLink.removeAttribute('href');
      }
    }
  })();

  /* ---------- reading voice ----------
     Strictly opt-in, and strictly language-matched: if the device has no
     voice in the requested language we stay silent rather than read the
     letter in the wrong accent. */
  const Narrator = (() => {
    const synth = window.speechSynthesis;
    const wanted = CFG.voice && !!synth && !RM;
    let voice = null, muted = false, queued = null, ranked = [], failed = 0, speaking = 0;

    function pick() {
      if (!wanted) return;
      const all = synth.getVoices();
      if (!all.length) return;
      const lang = (CFG.voiceLang || 'en-US').toLowerCase().replace('_', '-');
      const base = lang.split('-')[0];
      const norm = (v) => (v.lang || '').toLowerCase().replace('_', '-');

      // If a specific voice was named in CONFIG, honour it exactly.
      if (CFG.voiceName) {
        const exact = all.find((v) => v.name === CFG.voiceName);
        if (exact) { voice = exact; return; }
      }
      // Otherwise: only ever consider voices in the requested language.
      const pool = all.filter((v) => norm(v).split('-')[0] === base);
      if (!pool.length) { voice = null; ranked = []; return; }
      // Ranked by how warm and human they actually sound, best first.
      const score = (v) => {
        const n = (v.name || '').toLowerCase();
        let s = 0;
        if (/natural|neural/.test(n)) s += 300;             // Edge's modern voices
        else if (/online/.test(n)) s += 260;
        if (/premium|enhanced/.test(n)) s += 200;           // macOS/iOS upgraded
        if (/\bsamantha|\bava\b|\ballison|\bserena/.test(n)) s += 180; // warm Apple
        if (/aria|jenny|libby|sonia|emma|amber|michelle/.test(n)) s += 150;
        if (/google uk english female/.test(n)) s += 140;   // the kindest on Chrome
        if (/google us english/.test(n)) s += 110;
        if (/google.*female/.test(n)) s += 100;
        if (/google/.test(n)) s += 70;
        if (/female|woman/.test(n)) s += 25;
        if (/zira|hazel|susan/.test(n)) s += 20;
        if (/desktop/.test(n)) s -= 60;                     // old robotic SAPI
        if (/male|david|mark|george|guy|pavel/.test(n)) s -= 15;
        if (norm(v) === lang) s += 30;                      // exact region nudge
        return s;
      };
      ranked = pool.map((v) => [score(v), v]).sort((a, b) => b[0] - a[0]).map((p) => p[1]);
      voice = ranked[0];
    }

    if (wanted) {
      pick();
      if (synth.addEventListener) {
        synth.addEventListener('voiceschange', () => {
          pick();
          if (queued && voice) { const t = queued; queued = null; api.say(t); }
        });
      }
    }

    const api = {
      // only truly "on" once a correct-language voice actually exists
      get on() { return wanted && !!voice; },
      say(text) {
        if (!wanted || muted || !text || !text.trim()) return;
        if (!voice) {
          pick();
          // voices can arrive late on first load — hold the first line, drop the rest
          if (!voice) { if (!queued) queued = text; return; }
        }
        try {
          const u = new SpeechSynthesisUtterance(text);
          u.voice = voice;
          u.lang = voice.lang;
          u.rate = CFG.voiceRate;
          u.pitch = CFG.voicePitch;
          u.volume = CFG.voiceVolume;
          // let the piano fall back so the voice sits close and quiet
          u.onstart = () => AudioSys.duck(true);
          u.onend = () => { speaking--; if (speaking <= 0) AudioSys.duck(false); };
          // Google voices stream from the network; if one can't be reached,
          // step down to the next English voice instead of falling silent.
          u.onerror = (ev) => {
            speaking--;
            if (speaking <= 0) AudioSys.duck(false);
            if (ev && ev.error === 'interrupted') return;
            failed++;
            if (failed < ranked.length) {
              voice = ranked[failed];
              api.say(text);
            }
          };
          speaking++;
          synth.speak(u);
        } catch (e) { /* a device without speech support simply stays silent */ }
      },
      stop() { queued = null; speaking = 0; AudioSys.duck(false); if (synth) { try { synth.cancel(); } catch (e) { } } },
      setMuted(v) { muted = v; if (v) this.stop(); },
    };
    return api;
  })();
  /* Audition helpers — press F12 on the page and type:
       listVoices()                       see every voice your device has
       tryVoice("Google US English")      hear one read a line from the letter
     Then paste the winner into voiceName in the CONFIG block. */
  window.listVoices = () => (window.speechSynthesis
    ? speechSynthesis.getVoices().filter((v) => /^en/i.test(v.lang)).map((v) => v.name)
    : ['speech not supported']);
  window.tryVoice = (name, rate, pitch, volume) => {
    if (!window.speechSynthesis) return 'speech not supported';
    const v = speechSynthesis.getVoices().find((x) => x.name === name);
    if (!v) return 'no such voice — run listVoices() to see the names';
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance('Never stop believing in yourself. Happy Birthday.');
    u.voice = v; u.lang = v.lang;
    u.rate = rate != null ? rate : CFG.voiceRate;
    u.pitch = pitch != null ? pitch : CFG.voicePitch;
    u.volume = volume != null ? volume : CFG.voiceVolume;
    speechSynthesis.speak(u);
    return `${v.name} — rate ${u.rate}, pitch ${u.pitch}, volume ${u.volume}`;
  };

  const clamp01 = (v) => Math.max(0, Math.min(1, v));
  const easeIO = (t) => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  const easeO = (t) => 1 - Math.pow(1 - t, 3);
  const easeI = (t) => t * t * t;
  const smooth = (a, b, t) => easeIO(clamp01((t - a) / (b - a)));
  const lerp = (a, b, t) => a + (b - a) * t;

  /* ---------- renderer (with adaptive quality for slower devices) ---------- */
  const canvas = $('gl');
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  const PR_STEPS = PERF.mobile
    ? [0.75, 1.0, Math.min(window.devicePixelRatio, 1.6)]
    : [1.0, 1.35, Math.min(window.devicePixelRatio, 2)];
  let qLevel = 2;
  renderer.setPixelRatio(PR_STEPS[qLevel]);
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x8a6a4c);
  const camera = new THREE.PerspectiveCamera(44, window.innerWidth / window.innerHeight, 0.04, 40);
  camera.position.set(0.6, 1.15, 1.05);

  const W = World.build(renderer, scene);

  // letter sheet gets the real generated paper as its background
  const sheet = $('sheet');
  sheet.style.backgroundImage = `url(${W.paperURL})`;
  sheet.style.backgroundSize = '512px 512px';

  /* ---------- fx overlay canvas (gold dust, petals in 2D) ---------- */
  const Fx = (() => {
    const cv = $('fx');
    const ctx2 = cv.getContext('2d');
    let wpx = 0, hpx = 0, dpr = 1;
    const parts = [];
    function resize() {
      dpr = Math.min(window.devicePixelRatio, 2);
      wpx = window.innerWidth; hpx = window.innerHeight;
      cv.width = wpx * dpr; cv.height = hpx * dpr;
      ctx2.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    resize();
    window.addEventListener('resize', resize);
    let ambientGold = 0;   // particles per second
    let ambientPetal = 0;
    let acc = 0, accP = 0;
    function spawnGold(x, y, burst = false) {
      parts.push({
        kind: 'g',
        x, y,
        vx: (Math.random() - 0.5) * (burst ? 60 : 10),
        vy: burst ? -(20 + Math.random() * 55) : -(6 + Math.random() * 14),
        life: 0, max: 2.6 + Math.random() * 2.6,
        size: 0.8 + Math.random() * 1.9,
        tw: Math.random() * 10,
      });
    }
    function spawnPetal() {
      parts.push({
        kind: 'p',
        x: Math.random() * wpx, y: -20,
        vx: 0, vy: 24 + Math.random() * 26,
        sway: 30 + Math.random() * 40, ph: Math.random() * 9,
        rot: Math.random() * Math.PI, rv: (Math.random() - 0.5) * 1.6,
        life: 0, max: 30,
        size: 5 + Math.random() * 6,
        hue: 8 + Math.random() * 22, light: 78 + Math.random() * 10,
      });
    }
    function burst(x, y, n = 12) {
      for (let i = 0; i < n; i++) spawnGold(x + (Math.random() - 0.5) * 30, y + (Math.random() - 0.5) * 20, true);
    }
    function update(dt, t) {
      if (ambientGold > 0) {
        acc += dt * ambientGold;
        while (acc > 1) { spawnGold(Math.random() * wpx, hpx * (0.3 + Math.random() * 0.75)); acc -= 1; }
      }
      if (ambientPetal > 0) {
        accP += dt * ambientPetal;
        while (accP > 1) { spawnPetal(); accP -= 1; }
      }
      ctx2.clearRect(0, 0, wpx, hpx);
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i];
        p.life += dt;
        if (p.life > p.max || p.y > hpx + 30) { parts.splice(i, 1); continue; }
        if (p.kind === 'g') {
          p.x += p.vx * dt; p.y += p.vy * dt;
          p.vx *= (1 - dt * 0.6); p.vy *= (1 - dt * 0.4);
          p.y -= dt * 6;
          const k = p.life / p.max;
          const a = Math.sin(Math.PI * Math.min(1, k)) * (0.5 + 0.5 * Math.sin(t * 3 + p.tw));
          ctx2.globalCompositeOperation = 'lighter';
          const g = ctx2.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size * 3.2);
          g.addColorStop(0, `rgba(255,224,160,${0.75 * a})`);
          g.addColorStop(0.4, `rgba(232,168,92,${0.3 * a})`);
          g.addColorStop(1, 'rgba(232,168,92,0)');
          ctx2.fillStyle = g;
          ctx2.beginPath();
          ctx2.arc(p.x, p.y, p.size * 3.2, 0, Math.PI * 2);
          ctx2.fill();
        } else {
          p.y += p.vy * dt;
          p.x += Math.sin(p.life * 1.1 + p.ph) * p.sway * dt;
          p.rot += p.rv * dt;
          ctx2.globalCompositeOperation = 'source-over';
          ctx2.save();
          ctx2.translate(p.x, p.y);
          ctx2.rotate(p.rot + Math.sin(p.life * 2 + p.ph) * 0.4);
          ctx2.scale(1, 0.55 + 0.45 * Math.sin(p.life * 2.4 + p.ph));
          ctx2.fillStyle = `hsla(${p.hue},46%,${p.light}%,0.9)`;
          ctx2.beginPath();
          ctx2.ellipse(0, 0, p.size, p.size * 0.62, 0, 0, Math.PI * 2);
          ctx2.fill();
          ctx2.restore();
        }
      }
      ctx2.globalCompositeOperation = 'source-over';
    }
    return {
      update, burst,
      set gold(v) { ambientGold = v; },
      set petals(v) { ambientPetal = v; },
    };
  })();

  /* ---------- UI refs ---------- */
  const titleScreen = $('titleScreen');
  const fader = $('fader');
  const btnOpen = $('btnOpen');
  const btnSkip = $('btnSkip');
  const btnMute = $('btnMute');
  const letterWrap = $('letterWrap');
  const endCard = $('endCard');
  const vignette = $('vignette');

  /* ---------- state machine ---------- */
  let state = 'TITLE';
  let tState = 0;
  let elapsed = 0;
  const timers = [];
  function after(s, fn) { timers.push({ at: tState + s, fn }); }
  function setState(s) {
    state = s;
    tState = 0;
    timers.length = 0;
  }

  /* ---------- camera rig ---------- */
  const camGoal = { pos: camera.position.clone(), look: new THREE.Vector3(-0.05, 0.78, 0.03), fov: 44, rate: 2.6 };
  const camLook = camGoal.look.clone();
  function camUpdate(dt) {
    const k = 1 - Math.exp(-dt * camGoal.rate);
    camera.position.lerp(camGoal.pos, k);
    camLook.lerp(camGoal.look, k);
    camera.fov = lerp(camera.fov, camGoal.fov, k);
    camera.updateProjectionMatrix();
    const d = RM ? 0 : 1;
    camera.lookAt(
      camLook.x + Math.sin(elapsed * 0.31) * 0.011 * d,
      camLook.y + Math.sin(elapsed * 0.23 + 2) * 0.009 * d,
      camLook.z + Math.sin(elapsed * 0.27 + 4) * 0.008 * d
    );
  }
  function camTeleport() {
    camera.position.copy(camGoal.pos);
    camLook.copy(camGoal.look);
    camera.fov = camGoal.fov;
    camera.updateProjectionMatrix();
  }

  /* ---------- flight ---------- */
  const FLIGHT_START = 5.0, FLIGHT_DUR = 15.4;
  const tmpV = new THREE.Vector3(), tmpV2 = new THREE.Vector3(), tmpV3 = new THREE.Vector3();
  const ZERO = new THREE.Vector3(0, 0, 0), UP = new THREE.Vector3(0, 1, 0);
  const orbV = new THREE.Vector3(), poseV = new THREE.Vector3();
  const tmpQ = new THREE.Quaternion(), tmpM = new THREE.Matrix4();
  let prevHeading = 0, bank = 0, landed = false, lastTrail = 0;

  function flyPlane(t, dt) {
    const u = clamp01((t - FLIGHT_START) / FLIGHT_DUR);
    if (u <= 0) return 0;
    if (!W.plane.visible) W.plane.visible = true;
    const p = 1 - Math.pow(1 - u, 1.55);
    const pos = W.flightCurve.getPointAt(p, tmpV);
    // living air — fades out on approach
    const turb = Math.pow(1 - p, 0.6) * (RM ? 0 : 1);
    pos.x += Math.sin(elapsed * 1.7) * 0.012 * turb;
    pos.y += Math.sin(elapsed * 2.3 + 1.4) * 0.016 * turb;
    pos.z += Math.cos(elapsed * 1.3 + 2.6) * 0.01 * turb;
    W.plane.position.copy(pos);
    // orientation
    const tan = W.flightCurve.getTangentAt(p, tmpV2);
    const heading = Math.atan2(tan.x, tan.z);
    let dh = heading - prevHeading;
    if (dh > Math.PI) dh -= Math.PI * 2;
    if (dh < -Math.PI) dh += Math.PI * 2;
    prevHeading = heading;
    const targetBank = THREE.MathUtils.clamp(-dh / Math.max(dt, 0.001) * 0.42, -0.55, 0.55) * turb;
    bank = lerp(bank, targetBank, Math.min(1, dt * 4));
    tmpM.lookAt(ZERO, tmpV3.copy(tan).negate(), UP);
    W.plane.quaternion.setFromRotationMatrix(tmpM);
    W.plane.rotateZ(bank + Math.sin(elapsed * 2.2) * 0.03 * turb);
    // wing breath
    W.planeWings.L.rotation.z = Math.sin(elapsed * 2.4) * 0.025 * (0.3 + turb);
    W.planeWings.R.rotation.z = -Math.sin(elapsed * 2.4 + 0.4) * 0.025 * (0.3 + turb);
    // trail
    if (elapsed - lastTrail > 0.09 && u < 0.97) {
      W.emitTrail(pos, elapsed);
      lastTrail = elapsed;
    }
    return u;
  }

  function restPlane() {
    W.plane.visible = true;
    W.plane.position.copy(W.landPos);
    W.plane.rotation.set(0, W.landHeading, 0.015);
    W.planeWings.L.rotation.z = 0.01;
    W.planeWings.R.rotation.z = -0.01;
  }

  /* ---------- message writer ---------- */
  const HEADLINE = CFG.headline;
  const PARAS = CFG.paragraphs.length ? CFG.paragraphs : [
    "Today isn't just another birthday.",
    'Today marks the beginning of a beautiful new chapter.',
    'May every dream you chase find its way to you.',
    'May every challenge shape you into someone even stronger.',
    'May happiness follow every step you take.',
    'Never stop believing in yourself.',
    'Never stop smiling.',
    'And never forget how special you truly are.',
    'Happy Birthday.',
  ];
  const SIG = CFG.signature;
  // a flower blooms after every other paragraph, and after the last one
  const BLOOM_AFTER = new Set(PARAS.map((_, i) => i).filter((i) => i % 2 === 1 || i === PARAS.length - 1));
  const BLOOM_SPOTS = [
    { x: 7, y: 12 }, { x: 92, y: 18 }, { x: 5, y: 42 }, { x: 93, y: 55 },
    { x: 6, y: 74 }, { x: 91, y: 84 }, { x: 8, y: 94 }, { x: 90, y: 8 },
  ];
  const BLOOM_COLORS = [
    ['#d8a8a0', '#b98680'], ['#dfc08e', '#c09a58'], ['#b3c0a4', '#8fa07e'],
    ['#d8a8a0', '#b98680'], ['#dfc08e', '#c09a58'],
  ];
  let bloomCount = 0;

  function buildLetterDOM() {
    const inner = $('letterInner');
    const h = document.createElement('h2');
    h.className = 'headline';
    h.textContent = HEADLINE;
    inner.appendChild(h);
    const dateEl = document.createElement('div');
    dateEl.className = 'dateStamp';
    dateEl.textContent = CFG.birthdayDate || '';
    inner.appendChild(dateEl);
    const paraEls = PARAS.map((p) => {
      const el = document.createElement('p');
      el.className = 'para';
      for (const word of p.split(' ')) {
        const w = document.createElement('span');
        w.className = 'w';
        for (const ch of word) {
          const c = document.createElement('span');
          c.className = 'ch';
          c.textContent = ch;
          w.appendChild(c);
        }
        el.appendChild(w);
        el.appendChild(document.createTextNode(' '));
      }
      inner.appendChild(el);
      return el;
    });
    const sig = document.createElement('p');
    sig.className = 'sig';
    sig.textContent = SIG + ' ';
    const heart = document.createElement('span');
    heart.className = 'heart';
    heart.textContent = '❤';
    sig.appendChild(heart);
    inner.appendChild(sig);
    const sigName = document.createElement('p');
    sigName.className = 'sigName';
    sigName.textContent = CFG.fromName || '';
    inner.appendChild(sigName);
    return { h, dateEl, paraEls, sig, sigName };
  }
  const dom = buildLetterDOM();
  const nib = $('nib');

  function bloomSVG(colors) {
    const [fill, stroke] = colors;
    let petals = '';
    for (let i = 0; i < 6; i++) {
      petals += `<g class="pt" style="transition-delay:${i * 70}ms">
        <ellipse cx="27" cy="14" rx="6.5" ry="12" fill="${fill}" fill-opacity="0.9" stroke="${stroke}" stroke-width="0.8"
        transform="rotate(${i * 60} 27 27)"/></g>`;
    }
    return `<svg viewBox="0 0 54 54" width="54" height="54">
      ${petals}
      <circle class="core" cx="27" cy="27" r="4.4" fill="#c9a05c" stroke="#a37c3c" stroke-width="0.8"/>
    </svg>`;
  }

  function spawnBloom() {
    const spot = BLOOM_SPOTS[bloomCount % BLOOM_SPOTS.length];
    const div = document.createElement('div');
    div.className = 'bloom';
    div.style.left = spot.x + '%';
    div.style.top = spot.y + '%';
    div.style.transform = `translate(-50%,-50%) rotate(${Math.random() * 60 - 30}deg) scale(${0.7 + Math.random() * 0.5})`;
    div.innerHTML = bloomSVG(BLOOM_COLORS[bloomCount % BLOOM_COLORS.length]);
    $('blooms').appendChild(div);
    requestAnimationFrame(() => requestAnimationFrame(() => div.classList.add('on')));
    AudioSys.bloomPluck(bloomCount);
    const r = div.getBoundingClientRect();
    Fx.burst(r.left + r.width / 2, r.top + r.height / 2, 10);
    bloomCount++;
  }

  function autoScroll(el) {
    const target = el.offsetTop - sheet.clientHeight * 0.42;
    if (target > sheet.scrollTop) sheet.scrollTo({ top: target, behavior: 'smooth' });
  }

  /* The writer is driven by the render clock (never by setTimeout), so it
     stays perfectly in step with the film and survives tab throttling. */
  const writer = {
    active: false, steps: [], si: -1, phase: 'idle', t: 0,
    chars: null, ci: 0, delay: 0, dur: 0, pauseDur: 0, tick: 0, onDone: null,
  };
  function writerStart(onDone) {
    writer.steps = [];
    writer.steps.push({ kind: 'wipe', el: dom.h, dur: RM ? 0.4 : HEADLINE.length * 0.082, pauseAfter: 0.7, speak: HEADLINE });
    dom.paraEls.forEach((el, i) => {
      writer.steps.push({ kind: 'chars', el, pauseAfter: 0.62, bloom: BLOOM_AFTER.has(i), speak: PARAS[i] });
    });
    writer.steps.push({ kind: 'wipe', el: dom.sig, dur: RM ? 0.4 : 1.7, pauseAfter: CFG.fromName ? 0.35 : 0.5, bloom: true, speak: SIG });
    if (CFG.fromName) {
      writer.steps.push({ kind: 'wipe', el: dom.sigName, dur: RM ? 0.4 : 1.3, pauseAfter: 0.5, speak: CFG.fromName });
    }
    writer.si = -1;
    writer.onDone = onDone;
    writer.active = true;
    // the date settles onto the paper just before the first words
    if (dom.dateEl) setTimeout(() => dom.dateEl.classList.add('on'), 400);
    writerNext();
  }
  function writerNext() {
    writer.si++;
    if (writer.si >= writer.steps.length) {
      writer.active = false;
      if (writer.onDone) writer.onDone();
      return;
    }
    const s = writer.steps[writer.si];
    autoScroll(s.el);
    writer.t = 0;
    if (s.speak) Narrator.say(s.speak);
    if (s.kind === 'wipe') {
      writer.phase = 'wipe';
      writer.dur = s.dur;
      s.el.classList.add('writing');
      s.el.style.transition = `clip-path ${Math.round(s.dur * 1000)}ms cubic-bezier(.4,.0,.4,1)`;
      requestAnimationFrame(() => requestAnimationFrame(() => {
        s.el.style.clipPath = 'inset(-20% -5% -20% 0)';
      }));
    } else {
      writer.phase = 'chars';
      writer.chars = s.el.querySelectorAll('.ch');
      writer.ci = 0;
      writer.delay = 0;
      writer.tick = 0;
    }
  }
  function writerFinishStep() {
    const s = writer.steps[writer.si];
    if (s.kind === 'wipe') {
      s.el.classList.remove('writing');
      s.el.classList.add('done');
      s.el.style.clipPath = '';
      s.el.style.transition = '';
    } else {
      nib.style.opacity = 0;
    }
    if (s.bloom) spawnBloom();
    writer.phase = 'pause';
    writer.t = 0;
    writer.pauseDur = s.pauseAfter + (s.bloom ? 0.25 : 0);
  }
  function writerUpdate(dt) {
    if (!writer.active) return;
    writer.t += dt;
    if (writer.phase === 'wipe') {
      if (writer.t >= writer.dur + 0.06) writerFinishStep();
    } else if (writer.phase === 'chars') {
      writer.delay -= dt;
      let guard = 0;
      while (writer.delay <= 0 && writer.ci < writer.chars.length && guard++ < 40) {
        const ch = writer.chars[writer.ci++];
        ch.classList.add('on');
        if (!RM) {
          nib.style.opacity = 0.45;
          nib.style.left = (ch.offsetLeft + ch.offsetWidth + 1) + 'px';
          nib.style.top = (ch.offsetTop + ch.offsetHeight * 0.72) + 'px';
        }
        if (++writer.tick % 5 === 0) AudioSys.paper.scratch();
        const c = ch.textContent;
        let d = RM ? 0.008 : 0.03 + Math.random() * 0.014;
        if (c === ',') d += 0.19;
        if (c === '.') d += 0.32;
        writer.delay += d;
      }
      if (writer.ci >= writer.chars.length) writerFinishStep();
    } else if (writer.phase === 'pause') {
      if (writer.t >= writer.pauseDur) writerNext();
    }
  }

  /* ---------- opening sequence pieces ---------- */
  function animateOpening(t) {
    // seal halves separate 0.9–1.6
    if (t >= 0.9 && W.sealWhole.visible) {
      W.sealWhole.visible = false;
      W.sealL.visible = W.sealR.visible = true;
      AudioSys.sealCrack();
    }
    if (!W.sealWhole.visible) {
      const k = easeO(clamp01((t - 0.95) / 0.6));
      const lift = Math.sin(Math.PI * Math.min(1, k)) * 0.006;
      W.sealL.position.set(W.sealHome.x - 0.011 * k, W.sealHome.y + lift, W.sealHome.z + 0.002 * k);
      W.sealR.position.set(W.sealHome.x + 0.011 * k, W.sealHome.y + lift, W.sealHome.z - 0.001 * k);
      W.sealL.rotation.y = 0.35 * k;
      W.sealR.rotation.y = -0.28 * k;
    }
    // flap opens 1.7–3.2
    const f = smooth(1.7, 3.2, t);
    W.flapHinge.rotation.x = -2.55 * f;
    // letter slides out 3.3–5.1
    if (t >= 3.3 && !W.letterRoot.visible) {
      W.letterRoot.visible = true;
      AudioSys.paper.slide();
    }
    const s = smooth(3.3, 5.1, t);
    if (s > 0) {
      const off = tmpV.set(0, 0.009 - 0.005 * s, 0.02 + 0.185 * s);
      off.applyEuler(W.envelope.rotation);
      W.letterRoot.position.set(
        W.envelope.position.x + off.x,
        W.envelope.position.y + off.y,
        W.envelope.position.z + off.z
      );
    }
    // unfold 5.2–7.9
    const u1 = smooth(5.2, 6.7, t);
    W.hinge2.rotation.x = lerp(Math.PI - 0.06, 0.05, u1);
    const u2 = smooth(6.3, 7.9, t);
    W.hinge3.rotation.x = lerp(Math.PI - 0.06, -0.035, u2);
  }

  /* ---------- magic scene pieces ---------- */
  let brightK = 0;
  function animateMagic(t, dt) {
    // room brightens
    brightK = smooth(0.4, 3.4, t);
    renderer.toneMappingExposure = lerp(1.05, 1.34, brightK);
    W.hemi.intensity = lerp(0.6, 1.05, brightK);
    W.sparkleMat.uniforms.uAlpha.value = brightK * 0.9;
    W.beamMats.forEach((m, i) => { m.uniforms.uAlpha.value = (0.05 + i * 0.014) * (1 + brightK * 0.7); });
    // butterflies
    W.butterflies.forEach((b, i) => {
      const bt = t - 0.8 - i * 0.45;
      if (bt < 0) return;
      if (!b.visible) b.visible = true;
      const fade = clamp01(bt / 1.4);
      const u = b.userData;
      u.mats[0].opacity = fade;
      u.mats[1].opacity = fade * 0.95;
      u.mats[2].opacity = fade * 0.55;
      const a = bt * u.spd + u.seed;
      const px = u.center.x + Math.sin(a) * u.rx;
      const pz = u.center.z + Math.cos(a * 0.9) * u.rz;
      const py = u.center.y + Math.sin(bt * 0.8 + u.seed * 2) * 0.12 + Math.sin(bt * 5 + u.seed) * 0.013;
      tmpV.set(px, py, pz);
      tmpV2.copy(tmpV).sub(b.position);
      if (tmpV2.lengthSq() > 1e-8) {
        tmpM.lookAt(ZERO, tmpV3.copy(tmpV2).negate().setY(tmpV2.y * 0.3), UP);
        tmpQ.setFromRotationMatrix(tmpM);
        b.quaternion.slerp(tmpQ, Math.min(1, dt * 4));
      }
      b.position.copy(tmpV);
      const flap = Math.sin(bt * 13 + u.seed * 3) * (0.85 - 0.35 * Math.sin(bt * 0.7));
      u.wings[0].rotation.y = flap;
      u.wings[1].rotation.y = -flap;
    });
    // petals — drift down, rest a moment near the floor, then begin again
    if (t > 1.4) {
      if (!W.petals.visible) W.petals.visible = true;
      const dum = new THREE.Object3D();
      W.petalState.forEach((p, i) => {
        const pt = t - 1.4 - p.delay;
        if (pt < 0) {
          dum.position.set(0, -10, 0);
        } else {
          const cycle = (p.p.y - 0.03) / p.fall + 2.5;
          const fallT = pt % cycle;
          const y = Math.max(0.016, p.p.y - fallT * p.fall);
          dum.position.set(
            p.p.x + Math.sin(pt * 0.9 + p.phase) * 0.12,
            y,
            p.p.z + Math.cos(pt * 0.7 + p.phase) * 0.1
          );
          const settled = y <= 0.017;
          dum.rotation.set(
            settled ? Math.PI / 2 + Math.sin(p.phase) * 0.3 : pt * p.spin * 0.8 + p.phase,
            pt * p.spin * (settled ? 0 : 0.5),
            settled ? 0 : Math.sin(pt + p.phase) * 0.8
          );
        }
        dum.updateMatrix();
        W.petals.setMatrixAt(i, dum.matrix);
      });
      W.petals.instanceMatrix.needsUpdate = true;
    }
    // the airplane's farewell
    const LIFT0 = 3.4, LIFT1 = 5.4, CIRC1 = 9.8, EXIT1 = 12.8;
    const circleC = poseV.set(-0.16, 0.97, 0.16);
    const r0 = Math.hypot(W.landPos.x - circleC.x, W.landPos.z - circleC.z);
    const a0 = Math.atan2(W.landPos.x - circleC.x, W.landPos.z - circleC.z);
    if (t >= LIFT0 && t < LIFT1) {
      const k = easeIO((t - LIFT0) / (LIFT1 - LIFT0));
      W.plane.position.set(
        W.landPos.x,
        lerp(W.landPos.y, circleC.y, k) + Math.sin(k * Math.PI) * 0.03,
        W.landPos.z
      );
      W.plane.rotation.set(-0.35 * Math.sin(k * Math.PI), W.landHeading, Math.sin(elapsed * 2) * 0.04);
      W.planeWings.L.rotation.z = Math.sin(elapsed * 5) * 0.06 * k;
      W.planeWings.R.rotation.z = -Math.sin(elapsed * 5 + 0.3) * 0.06 * k;
    } else if (t >= LIFT1 && t < CIRC1) {
      const k = (t - LIFT1) / (CIRC1 - LIFT1);
      const a = a0 + k * Math.PI * 2;
      const px = circleC.x + Math.sin(a) * r0;
      const pz = circleC.z + Math.cos(a) * r0;
      const py = circleC.y + Math.sin(k * Math.PI * 2) * 0.05;
      W.plane.position.set(px, py, pz);
      const heading = Math.atan2(Math.cos(a), -Math.sin(a));
      W.plane.rotation.set(0, heading, 0);
      W.plane.rotateZ(-0.38);
      if (elapsed - lastTrail > 0.1) { W.emitTrail(W.plane.position, elapsed); lastTrail = elapsed; }
    } else if (t >= CIRC1 && t < EXIT1 + 1) {
      const k = clamp01((t - CIRC1) / (EXIT1 - CIRC1));
      const p = easeI(k) * 0.15 + k * 0.85;
      W.exitCurve.getPointAt(clamp01(p), tmpV);
      W.plane.position.copy(tmpV);
      const tan = W.exitCurve.getTangentAt(clamp01(p), tmpV2);
      tmpM.lookAt(ZERO, tmpV3.copy(tan).negate(), UP);
      W.plane.quaternion.setFromRotationMatrix(tmpM);
      W.plane.rotateZ(Math.sin(k * Math.PI) * -0.25);
      if (elapsed - lastTrail > 0.12) { W.emitTrail(W.plane.position, elapsed); lastTrail = elapsed; }
    }
  }

  /* ---------- state handlers ---------- */
  const handlers = {
    TITLE() {
      camGoal.pos.set(0.62, 1.14, 1.02);
      camGoal.look.set(-0.05, 0.78, 0.03);
    },
    ARRIVAL(dt) {
      const t = tState;
      // opening orbit
      const oa = lerp(0.55, -0.75, easeIO(clamp01(t / 11)));
      const or = lerp(1.18, 0.98, clamp01(t / 11));
      const oh = lerp(1.18, 1.0, clamp01(t / 11));
      orbV.set(Math.sin(oa) * or - 0.05, oh, Math.cos(oa) * or + 0.03);
      const orbLook = { x: -0.09, y: 0.77, z: 0.03 };
      const u = flyPlane(t, dt);
      // chase blend
      const wChase = smooth(6.2, 8.4, t) * (1 - smooth(0.845, 0.9, u));
      const wLand = smooth(0.845, 0.9, u);
      if (wChase > 0 || wLand > 0) {
        const fwd = tmpV2.set(0, 0, 1).applyQuaternion(W.plane.quaternion);
        const side = tmpV3.set(1, 0, 0).applyQuaternion(W.plane.quaternion);
        const chasePos = W.plane.position.clone().addScaledVector(fwd, -0.5).addScaledVector(side, 0.2);
        chasePos.y += 0.16;
        if (chasePos.y < 0.3) chasePos.y = 0.3;
        const chaseLook = W.plane.position.clone().addScaledVector(fwd, 0.55);
        const landLook = { x: 0.08, y: 0.775, z: 0.06 };
        camGoal.pos.copy(orbV).lerp(chasePos, wChase).lerp(poseV.set(0.68, 1.0, 0.92), wLand);
        camGoal.look.set(
          lerp(lerp(orbLook.x, chaseLook.x, wChase), landLook.x, wLand),
          lerp(lerp(orbLook.y, chaseLook.y, wChase), landLook.y, wLand),
          lerp(lerp(orbLook.z, chaseLook.z, wChase), landLook.z, wLand)
        );
        camGoal.fov = lerp(lerp(44, 56, wChase), 46, wLand);
        camGoal.rate = lerp(2.6, 5.2, wChase);
      } else {
        camGoal.pos.copy(orbV);
        camGoal.look.set(orbLook.x, orbLook.y, orbLook.z);
      }
      // touchdown
      if (u >= 1 && !landed) {
        landed = true;
        AudioSys.paper.land();
        W.poof.material.uniforms.uT.value = 0;
        W.poof.material.uniforms.uOrigin.value.copy(W.landPos);
        restPlane();
        W.plane.scale.set(1, 0.86, 1);
        after(0.05, () => { });
        setState('LANDED');
        btnSkip.classList.add('hidden');
        after(1.6, () => btnOpen.classList.remove('hidden'));
      }
    },
    LANDED() {
      // settle squash back
      W.plane.scale.y = lerp(W.plane.scale.y, 1, 0.12);
      camGoal.pos.set(0.5, 1.0, 0.72);
      camGoal.look.set(-0.04, 0.775, 0.05);
      camGoal.fov = 42;
      camGoal.rate = 1.6;
      // tiny paper settle
      W.plane.rotation.z = 0.015 + Math.sin(elapsed * 0.5) * 0.003;
    },
    OPENING() {
      const t = tState;
      animateOpening(t);
      if (t < 2.4) {
        camGoal.pos.set(0.06, 1.22, 0.66);
        camGoal.look.set(-0.13, 0.77, 0.03);
        camGoal.fov = 40;
        camGoal.rate = 2.0;
      } else if (t < 5.2) {
        camGoal.pos.set(-0.02, 1.12, 0.55);
        camGoal.look.set(-0.15, 0.77, 0.1);
      } else {
        camGoal.pos.set(-0.05, 0.99, 0.44);
        camGoal.look.set(-0.17, 0.767, 0.19);
        camGoal.fov = 38;
      }
    },
    MESSAGE(dt) {
      camGoal.pos.set(-0.02, 1.0, 0.46);
      camGoal.look.set(-0.17, 0.767, 0.19);
      camGoal.rate = 1.2;
      writerUpdate(dt);
    },
    MAGIC(dt) {
      const t = tState;
      animateMagic(t, dt);
      if (t < 9.8) {
        camGoal.pos.set(0.72, 1.18, 1.02);
        camGoal.look.set(-0.16, 0.9, 0.16);
        camGoal.fov = 46;
        camGoal.rate = 1.4;
      } else {
        const k = smooth(9.8, 11.8, t);
        camGoal.pos.set(lerp(0.72, 0.55, k), lerp(1.18, 1.3, k), lerp(1.02, 0.85, k));
        camGoal.look.set(
          lerp(-0.16, W.windowCenter.x + 0.4, k),
          lerp(0.9, W.windowCenter.y, k),
          lerp(0.16, W.windowCenter.z, k)
        );
        camGoal.fov = lerp(46, 52, k);
      }
    },
    END() { },
  };

  /* ---------- transitions ---------- */
  function begin() {
    AudioSys.init();
    AudioSys.resume();
    titleScreen.classList.add('gone');
    vignette.classList.add('on');
    setState(RM ? 'LANDED' : 'ARRIVAL');
    if (RM) {
      restPlane();
      landed = true;
      camGoal.pos.set(0.5, 1.0, 0.72);
      camGoal.look.set(-0.04, 0.775, 0.05);
      camTeleport();
      setTimeout(() => btnOpen.classList.remove('hidden'), 1200);
      AudioSys.startMusic();
    } else {
      setTimeout(() => AudioSys.startMusic(), 2000);
      setTimeout(() => { if (state === 'ARRIVAL') btnSkip.classList.remove('hidden'); }, 6000);
    }
  }

  function skipIntro() {
    if (state !== 'ARRIVAL') return;
    btnSkip.classList.add('hidden');
    fader.style.transition = 'opacity 0.5s ease';
    fader.style.opacity = 1;
    setTimeout(() => {
      restPlane();
      landed = true;
      setState('LANDED');
      camGoal.pos.set(0.5, 1.0, 0.72);
      camGoal.look.set(-0.04, 0.775, 0.05);
      camGoal.fov = 42;
      camTeleport();
      btnOpen.classList.remove('hidden');
      fader.style.opacity = 0;
      setTimeout(() => { fader.style.transition = ''; }, 600);
    }, 520);
  }

  function openLetter() {
    if (state !== 'LANDED') return;
    btnOpen.classList.add('hidden');
    setState('OPENING');
    after(1.7, () => AudioSys.paper.flap());
    after(5.3, () => AudioSys.paper.unfold());
    after(6.4, () => AudioSys.paper.unfold());
    after(8.3, () => {
      letterWrap.classList.remove('hidden');
      Fx.gold = 2.2;
    });
    after(8.9, () => {
      setState('MESSAGE');
      after(0.7, () => writerStart(() => after(2.3, startMagic)));
    });
  }

  function startMagic() {
    setState('MAGIC');
    letterWrap.classList.add('hidden');
    Fx.gold = 5;
    AudioSys.magicChime();
    after(12.4, () => { fader.style.opacity = 1; });
    after(13.2, () => AudioSys.finale());
    after(13.9, () => {
      setState('END');
      endCard.classList.remove('hidden');
      Fx.gold = 3;
      Fx.petals = RM ? 0.6 : 1.6;
      setTimeout(() => { fader.style.opacity = 0; }, 250);
    });
  }

  /* ---------- wire UI ---------- */
  $('btnBegin').addEventListener('click', begin);
  btnOpen.addEventListener('click', openLetter);
  btnSkip.addEventListener('click', skipIntro);
  $('btnReplay').addEventListener('click', () => { Narrator.stop(); location.reload(); });
  btnMute.addEventListener('click', () => {
    const m = !AudioSys.muted;
    AudioSys.setMuted(m);
    Narrator.setMuted(m);
    btnMute.classList.toggle('muted', m);
    btnMute.setAttribute('aria-label', m ? 'Unmute' : 'Mute');
  });
  // browsers keep speaking after the tab closes unless we cancel
  window.addEventListener('pagehide', () => Narrator.stop());

  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  /* ---------- main loop ---------- */
  const clock = new THREE.Clock();
  let perfAcc = 0, perfN = 0, curtainTick = 0;
  window.__dbg = () => JSON.stringify({
    state, t: +tState.toFixed(2), e: +elapsed.toFixed(2), q: qLevel,
    cam: camera.position.toArray().map((n) => +n.toFixed(2)),
    plane: W.plane.visible ? W.plane.position.toArray().map((n) => +n.toFixed(2)) : null,
    err: window.__errors || [],
  });
  function tick(dt, doRender = true) {
    elapsed += dt;
    tState += dt;
    try {
      // timers
      for (let i = timers.length - 1; i >= 0; i--) {
        if (tState >= timers[i].at) {
          const fn = timers[i].fn;
          timers.splice(i, 1);
          fn();
        }
      }
      (handlers[state] || (() => { }))(dt);
      camUpdate(dt);
      // ambient world life — curtain sim every other frame, it's the only CPU geometry
      if (!RM && (curtainTick++ & 1) === 0) W.updateCurtain(elapsed);
      W.beamMats.forEach((m) => { m.uniforms.uTime.value = elapsed; });
      W.dustMats.forEach((m) => { m.uniforms.uTime.value = elapsed; });
      W.sparkleMat.uniforms.uTime.value = elapsed;
      W.trailMat.uniforms.uNow.value = elapsed;
      if (W.poof.material.uniforms.uT.value < 2) W.poof.material.uniforms.uT.value += dt;
      Fx.update(dt, elapsed);
    } catch (err) {
      (window.__errors = window.__errors || []).push(String(err && err.stack || err));
    }
    if (doRender) renderer.render(scene, camera);
  }
  renderer.setAnimationLoop(() => {
    const dt = Math.min(clock.getDelta(), 0.05);
    tick(dt);
    // adaptive quality — if a device can't keep up, quietly lower resolution
    perfAcc += dt; perfN++;
    if (perfN >= 100) {
      if (perfAcc / perfN > 0.024 && qLevel > 0) {
        qLevel--;
        renderer.setPixelRatio(PR_STEPS[qLevel]);
      }
      perfAcc = 0; perfN = 0;
    }
  });
  // manual time pump — used for automated review; harmless in normal playback
  window.__tick = (dt, n) => {
    n = n || 1;
    for (let i = 0; i < n - 1; i++) tick(dt, false);
    tick(dt, true);
    clock.getDelta();
    return window.__dbg();
  };
  window.__magic = startMagic;
})();
