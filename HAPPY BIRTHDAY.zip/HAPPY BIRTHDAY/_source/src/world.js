/* ============================================================
   WORLD — the room at golden hour. Procedural textures, PBR
   materials, volumetric light, dust, and every prop on the desk.
   ============================================================ */
const PERF = {
  mobile: window.matchMedia('(pointer: coarse)').matches || Math.min(window.innerWidth, window.innerHeight) < 560,
};

const World = (() => {
  const W = {};

  /* ---------- canvas texture helpers ---------- */
  function canv(w, h) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    return [c, c.getContext('2d')];
  }
  function tex(c, srgb = true, repeat = null) {
    const t = new THREE.CanvasTexture(c);
    if (srgb) t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 8;
    if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(repeat[0], repeat[1]); }
    return t;
  }
  const rnd = (a, b) => a + Math.random() * (b - a);

  function woodTexture(base = '#5a4128', dark = '#3a2817', light = '#77563a', w = 1024, h = 1024) {
    const [c, x] = canv(w, h);
    x.fillStyle = base; x.fillRect(0, 0, w, h);
    // broad tonal bands first (boards)
    for (let b = 0; b < 6; b++) {
      x.globalAlpha = 0.1;
      x.fillStyle = Math.random() < 0.5 ? dark : light;
      x.fillRect(0, (b / 6) * h + rnd(-20, 20), w, h / 6 + rnd(-10, 30));
    }
    // long fine grain strokes
    for (let i = 0; i < 1700; i++) {
      const y = Math.random() * h;
      const len = rnd(180, w * 1.2);
      const sx = Math.random() * w - len / 2;
      const amp = rnd(0.6, 5);
      x.strokeStyle = Math.random() < 0.55 ? dark : light;
      x.globalAlpha = rnd(0.015, 0.065);
      x.lineWidth = rnd(0.35, 1.9);
      x.beginPath();
      for (let px = 0; px <= len; px += 12) {
        const py = y + Math.sin(px * 0.012 + i) * amp + Math.sin(px * 0.05 + i * 2.7) * 0.8;
        px === 0 ? x.moveTo(sx + px, py) : x.lineTo(sx + px, py);
      }
      x.stroke();
    }
    // subtle knots
    for (let i = 0; i < 4; i++) {
      const kx = Math.random() * w, ky = Math.random() * h;
      for (let r = 22; r > 2; r -= 3) {
        x.globalAlpha = 0.045;
        x.strokeStyle = dark;
        x.lineWidth = 1.2;
        x.beginPath();
        x.ellipse(kx, ky, r * 1.9, r, 0.25, 0, Math.PI * 2);
        x.stroke();
      }
    }
    x.globalAlpha = 1;
    return c;
  }

  function paperCanvas(base = '#f6efe3', fiber = '#d8cbb2', w = 512, h = 512, density = 2600) {
    const [c, x] = canv(w, h);
    x.fillStyle = base; x.fillRect(0, 0, w, h);
    for (let i = 0; i < density; i++) {
      x.strokeStyle = Math.random() < 0.75 ? fiber : '#ffffff';
      x.globalAlpha = rnd(0.03, 0.1);
      x.lineWidth = rnd(0.4, 1.1);
      const px = Math.random() * w, py = Math.random() * h, a = Math.random() * Math.PI;
      const l = rnd(2, 9);
      x.beginPath();
      x.moveTo(px, py);
      x.lineTo(px + Math.cos(a) * l, py + Math.sin(a) * l);
      x.stroke();
    }
    // faint mottling
    for (let i = 0; i < 40; i++) {
      const mx = Math.random() * w, my = Math.random() * h;
      const g = x.createRadialGradient(mx, my, 2, mx, my, rnd(40, 130));
      g.addColorStop(0, 'rgba(190,168,132,0.04)');
      g.addColorStop(1, 'rgba(190,168,132,0)');
      x.globalAlpha = 1;
      x.fillStyle = g;
      x.fillRect(0, 0, w, h);
    }
    x.globalAlpha = 1;
    return c;
  }

  function plasterCanvas(base = '#e4d6bd') {
    const [c, x] = canv(512, 512);
    x.fillStyle = base; x.fillRect(0, 0, 512, 512);
    for (let i = 0; i < 6500; i++) {
      x.fillStyle = Math.random() < 0.5 ? 'rgba(115,92,62,0.028)' : 'rgba(255,250,238,0.045)';
      x.fillRect(Math.random() * 512, Math.random() * 512, rnd(0.5, 2.2), rnd(0.5, 2.2));
    }
    // soft blotches so large walls don't read flat
    for (let i = 0; i < 22; i++) {
      const bx = Math.random() * 512, by = Math.random() * 512;
      const g = x.createRadialGradient(bx, by, 4, bx, by, rnd(60, 190));
      g.addColorStop(0, 'rgba(150,120,84,0.04)');
      g.addColorStop(1, 'rgba(150,120,84,0)');
      x.fillStyle = g;
      x.fillRect(0, 0, 512, 512);
    }
    return c;
  }

  function floorCanvas() {
    const [c, x] = canv(1024, 1024);
    const plankH = 1024 / 7;
    for (let p = 0; p < 7; p++) {
      const shade = 0.9 + Math.random() * 0.2;
      x.fillStyle = `rgb(${Math.floor(168 * shade)},${Math.floor(130 * shade)},${Math.floor(90 * shade)})`;
      x.fillRect(0, p * plankH, 1024, plankH);
      for (let i = 0; i < 170; i++) {
        x.strokeStyle = Math.random() < 0.5 ? 'rgba(90,60,35,0.09)' : 'rgba(215,180,135,0.08)';
        x.lineWidth = rnd(0.5, 2);
        const y = p * plankH + Math.random() * plankH;
        x.beginPath(); x.moveTo(0, y);
        for (let px = 0; px <= 1024; px += 32) x.lineTo(px, y + Math.sin(px * 0.008 + i) * 2.5);
        x.stroke();
      }
      x.fillStyle = 'rgba(50,32,18,0.5)';
      x.fillRect(0, p * plankH, 1024, 2.5);
      // plank end seams
      const seam = Math.random() * 1024;
      x.fillRect(seam, p * plankH, 2, plankH);
    }
    return c;
  }

  function sealBumpCanvas() {
    const [c, x] = canv(256, 256);
    x.fillStyle = '#808080'; x.fillRect(0, 0, 256, 256);
    x.strokeStyle = '#c9c9c9';
    x.lineWidth = 7;
    x.beginPath(); x.arc(128, 128, 96, 0, Math.PI * 2); x.stroke();
    x.lineWidth = 3;
    x.beginPath(); x.arc(128, 128, 82, 0, Math.PI * 2); x.stroke();
    // monogram — the initial of whoever signed the letter, else a heart
    const from = (window.CONFIG && window.CONFIG.fromName || '').trim();
    const mark = from ? from[0].toUpperCase() : '♥';
    x.fillStyle = '#d8d8d8';
    x.font = `600 ${from ? 118 : 104}px Georgia, serif`;
    x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText(mark, 128, 136);
    // rim irregularity
    for (let i = 0; i < 26; i++) {
      const a = Math.random() * Math.PI * 2;
      x.fillStyle = 'rgba(60,60,60,0.5)';
      x.beginPath();
      x.arc(128 + Math.cos(a) * rnd(100, 120), 128 + Math.sin(a) * rnd(100, 120), rnd(4, 14), 0, Math.PI * 2);
      x.fill();
    }
    return c;
  }

  function handwritingCanvas() {
    // faint script hints on the unfolded 3D letter (the DOM overlay carries the real text)
    const c = paperCanvas('#f6efe3', '#dccfb6', 512, 760, 2000);
    const x = c.getContext('2d');
    x.strokeStyle = 'rgba(58,49,40,0.34)';
    x.lineWidth = 1.5;
    x.filter = 'blur(0.6px)';
    let y = 96;
    // headline squiggle centered
    x.beginPath();
    for (let px = 130; px < 382; px += 4) {
      const py = 60 + Math.sin(px * 0.11) * 7 + Math.sin(px * 0.31) * 3;
      px === 130 ? x.moveTo(px, py) : x.lineTo(px, py);
    }
    x.stroke();
    y = 130;
    for (let line = 0; line < 14; line++) {
      const indent = 60 + Math.random() * 20;
      const end = 452 - Math.random() * 60;
      x.beginPath();
      for (let px = indent; px < end; px += 4) {
        const py = y + Math.sin(px * 0.13 + line * 2.1) * 4 + Math.sin(px * 0.41 + line) * 1.6;
        px === indent ? x.moveTo(px, py) : x.lineTo(px, py);
      }
      x.stroke();
      y += 42 + (line % 4 === 3 ? 16 : 0);
    }
    x.filter = 'none';
    return c;
  }

  function skyCanvas() {
    const [c, x] = canv(512, 512);
    const g = x.createLinearGradient(0, 0, 0, 512);
    g.addColorStop(0, '#f7d9a8');
    g.addColorStop(0.42, '#f2b877');
    g.addColorStop(0.72, '#e08d52');
    g.addColorStop(1, '#b96a3e');
    x.fillStyle = g; x.fillRect(0, 0, 512, 512);
    // sun glow
    const sg = x.createRadialGradient(330, 250, 8, 330, 250, 240);
    sg.addColorStop(0, 'rgba(255,244,214,0.98)');
    sg.addColorStop(0.18, 'rgba(255,226,168,0.75)');
    sg.addColorStop(1, 'rgba(255,210,140,0)');
    x.fillStyle = sg; x.fillRect(0, 0, 512, 512);
    // soft distant treeline
    x.fillStyle = 'rgba(110,70,50,0.5)';
    for (let i = 0; i < 26; i++) {
      const bx = Math.random() * 512, bw = rnd(30, 90), bh = rnd(24, 70);
      x.beginPath(); x.ellipse(bx, 470 - bh * 0.3, bw, bh, 0, 0, Math.PI * 2); x.fill();
    }
    x.filter = 'blur(6px)';
    x.drawImage(c, 0, 0);
    x.filter = 'none';
    return c;
  }

  function glowSprite(inner = 'rgba(255,232,190,1)', outer = 'rgba(255,190,110,0)') {
    const [c, x] = canv(128, 128);
    const g = x.createRadialGradient(64, 64, 2, 64, 64, 62);
    g.addColorStop(0, inner);
    g.addColorStop(0.35, inner.replace('1)', '0.45)'));
    g.addColorStop(1, outer);
    x.fillStyle = g; x.fillRect(0, 0, 128, 128);
    return c;
  }

  function butterflyWingCanvas() {
    const [c, x] = canv(128, 128);
    x.clearRect(0, 0, 128, 128);
    const g = x.createRadialGradient(18, 66, 4, 60, 60, 90);
    g.addColorStop(0, 'rgba(255,224,160,0.98)');
    g.addColorStop(0.55, 'rgba(240,186,110,0.92)');
    g.addColorStop(1, 'rgba(196,130,70,0.85)');
    x.fillStyle = g;
    // fore + hind wing lobes
    x.beginPath();
    x.moveTo(6, 66);
    x.bezierCurveTo(20, 6, 96, 2, 118, 34);
    x.bezierCurveTo(122, 58, 92, 66, 62, 68);
    x.bezierCurveTo(100, 74, 110, 96, 92, 114);
    x.bezierCurveTo(66, 126, 22, 106, 6, 66);
    x.closePath();
    x.fill();
    // veins
    x.strokeStyle = 'rgba(150,90,44,0.5)';
    x.lineWidth = 1.6;
    for (const [cx, cy] of [[104, 30], [88, 52], [92, 100], [64, 108]]) {
      x.beginPath(); x.moveTo(10, 66); x.quadraticCurveTo((10 + cx) / 2, cy - 12, cx, cy); x.stroke();
    }
    return c;
  }

  /* ---------- environment (soft warm IBL) ---------- */
  function buildEnvironment(renderer) {
    const envScene = new THREE.Scene();
    const grad = new THREE.Mesh(
      new THREE.SphereGeometry(10, 32, 24),
      new THREE.MeshBasicMaterial({ side: THREE.BackSide })
    );
    const [c, x] = canv(64, 64);
    const g = x.createLinearGradient(0, 0, 0, 64);
    g.addColorStop(0, '#f0d5a8');
    g.addColorStop(0.5, '#b09270');
    g.addColorStop(1, '#4c3a28');
    x.fillStyle = g; x.fillRect(0, 0, 64, 64);
    grad.material.map = tex(c);
    envScene.add(grad);
    // hot window card for specular interest
    const win = new THREE.Mesh(
      new THREE.PlaneGeometry(4, 5),
      new THREE.MeshBasicMaterial({ color: 0xffe9c0 })
    );
    win.position.set(-7, 3, -2); win.lookAt(0, 1, 0);
    win.material.color.multiplyScalar(6);
    envScene.add(win);
    const pmrem = new THREE.PMREMGenerator(renderer);
    const rt = pmrem.fromScene(envScene, 0.06);
    pmrem.dispose();
    return rt.texture;
  }

  /* ---------- volumetric beam shader ---------- */
  function beamMaterial(alpha = 0.07) {
    return new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      uniforms: {
        uTime: { value: 0 },
        uAlpha: { value: alpha },
        uColor: { value: new THREE.Color(0xffd9a0) },
      },
      vertexShader: `
        varying vec2 vUv;
        void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
      fragmentShader: `
        uniform float uTime; uniform float uAlpha; uniform vec3 uColor;
        varying vec2 vUv;
        float n(vec2 p){ return fract(sin(dot(p, vec2(41.3,289.1)))*43758.5453); }
        float noise(vec2 p){
          vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
          return mix(mix(n(i),n(i+vec2(1,0)),f.x), mix(n(i+vec2(0,1)),n(i+vec2(1,1)),f.x), f.y);
        }
        void main(){
          float edgeU = smoothstep(0.0,0.32,vUv.x)*smoothstep(1.0,0.68,vUv.x);
          float edgeV = smoothstep(0.0,0.12,vUv.y)*smoothstep(1.0,0.35,vUv.y);
          float shafts = 0.6 + 0.4*noise(vec2(vUv.x*9.0, vUv.y*2.0 - uTime*0.05));
          float drift = 0.75 + 0.25*noise(vec2(vUv.x*3.0 + uTime*0.03, vUv.y*1.2));
          gl_FragColor = vec4(uColor, uAlpha * edgeU * edgeV * shafts * drift);
        }`,
    });
  }

  /* ---------- dust points ---------- */
  function dustPoints(count, box, color = 0xffe3b8, size = 2.6, alpha = 0.55) {
    const pos = new Float32Array(count * 3);
    const seed = new Float32Array(count);
    const spd = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = rnd(box.min.x, box.max.x);
      pos[i * 3 + 1] = rnd(box.min.y, box.max.y);
      pos[i * 3 + 2] = rnd(box.min.z, box.max.z);
      seed[i] = Math.random() * 100;
      spd[i * 3] = rnd(-0.006, 0.006);
      spd[i * 3 + 1] = rnd(-0.004, 0.004);
      spd[i * 3 + 2] = rnd(-0.006, 0.006);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1));
    const mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: {
        uTime: { value: 0 },
        uColor: { value: new THREE.Color(color) },
        uSize: { value: size * Math.min(window.devicePixelRatio, 2) },
        uAlpha: { value: alpha },
      },
      vertexShader: `
        attribute float aSeed;
        uniform float uTime; uniform float uSize;
        varying float vTw;
        void main(){
          vec3 p = position;
          p.x += sin(uTime*0.14 + aSeed)*0.05;
          p.y += sin(uTime*0.1 + aSeed*1.7)*0.04;
          p.z += cos(uTime*0.12 + aSeed*0.9)*0.05;
          vec4 mv = modelViewMatrix * vec4(p,1.0);
          gl_PointSize = uSize * (1.6 / -mv.z) * (0.6 + 0.4*sin(aSeed*3.1));
          vTw = 0.45 + 0.55*sin(uTime*(0.5+fract(aSeed)*0.8) + aSeed*7.0);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        uniform vec3 uColor; uniform float uAlpha;
        varying float vTw;
        void main(){
          vec2 d = gl_PointCoord - 0.5;
          float m = smoothstep(0.5, 0.08, length(d));
          gl_FragColor = vec4(uColor, m * uAlpha * vTw);
        }`,
    });
    return new THREE.Points(geo, mat);
  }

  /* ---------- soft contact-shadow decal ---------- */
  let aoTex = null;
  function aoDecal(w, d, opacity = 0.32) {
    if (!aoTex) {
      const [c, x] = canv(128, 128);
      const g = x.createRadialGradient(64, 64, 6, 64, 64, 62);
      g.addColorStop(0, 'rgba(0,0,0,1)');
      g.addColorStop(0.6, 'rgba(0,0,0,0.55)');
      g.addColorStop(1, 'rgba(0,0,0,0)');
      x.fillStyle = g; x.fillRect(0, 0, 128, 128);
      aoTex = new THREE.CanvasTexture(c);
    }
    const m = new THREE.Mesh(
      new THREE.PlaneGeometry(w, d),
      new THREE.MeshBasicMaterial({ map: aoTex, transparent: true, opacity, depthWrite: false, color: 0x1a0f06 })
    );
    m.rotation.x = -Math.PI / 2;
    m.renderOrder = 1;
    return m;
  }

  /* ============================================================
     BUILD
     ============================================================ */
  function build(renderer, scene) {
    const env = buildEnvironment(renderer);
    scene.environment = env;
    scene.fog = new THREE.FogExp2(0x8a6a4c, 0.028);

    const paperTexC = paperCanvas();
    W.paperURL = paperTexC.toDataURL('image/jpeg', 0.85);

    /* ----- lights ----- */
    const sun = new THREE.DirectionalLight(0xffd9a8, 4.2);
    sun.position.set(-7, 3.9, -2.2);
    sun.target.position.set(1.4, 0, 0.5);
    sun.castShadow = true;
    const smap = PERF.mobile ? 1024 : 2048;
    sun.shadow.mapSize.set(smap, smap);
    sun.shadow.camera.near = 1;
    sun.shadow.camera.far = 16;
    sun.shadow.camera.left = -3.6; sun.shadow.camera.right = 3.6;
    sun.shadow.camera.top = 3.4; sun.shadow.camera.bottom = -1.5;
    sun.shadow.bias = -0.0004;
    sun.shadow.normalBias = 0.015;
    scene.add(sun, sun.target);
    W.sun = sun;

    const hemi = new THREE.HemisphereLight(0xffe6c4, 0x54422e, 0.6);
    scene.add(hemi);
    W.hemi = hemi;

    const bounce = new THREE.PointLight(0xff9c5e, 0.5, 5, 2);
    bounce.position.set(-1.6, 0.5, -0.4);
    scene.add(bounce);

    const deskFill = new THREE.PointLight(0xffe2b8, 0.35, 4, 2);
    deskFill.position.set(0.9, 1.5, 1.3);
    scene.add(deskFill);

    /* ----- room shell ----- */
    const plaster = tex(plasterCanvas(), true, [3, 2]);
    const wallMat = new THREE.MeshStandardMaterial({ map: plaster, roughness: 0.95, metalness: 0 });
    const ROOM = { w: 6.4, h: 3.1, d: 5.4 };

    const floor = new THREE.Mesh(new THREE.PlaneGeometry(ROOM.w, ROOM.d), new THREE.MeshStandardMaterial({
      map: tex(floorCanvas(), true, [2.2, 2.2]), roughness: 0.55, metalness: 0.02, envMapIntensity: 0.7,
    }));
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);

    const ceil = new THREE.Mesh(new THREE.PlaneGeometry(ROOM.w, ROOM.d), wallMat.clone());
    ceil.rotation.x = Math.PI / 2;
    ceil.position.y = ROOM.h;
    scene.add(ceil);

    function wall(wd, ht, px, py, pz, ry) {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(wd, ht), wallMat);
      m.position.set(px, py, pz);
      m.rotation.y = ry;
      m.receiveShadow = true;
      scene.add(m);
      return m;
    }
    wall(ROOM.w, ROOM.h, 0, ROOM.h / 2, -ROOM.d / 2, 0);            // back
    wall(ROOM.w, ROOM.h, 0, ROOM.h / 2, ROOM.d / 2, Math.PI);       // front
    wall(ROOM.d, ROOM.h, ROOM.w / 2, ROOM.h / 2, 0, -Math.PI / 2);  // right

    // left wall with window hole — window x=-3.2, opening 1.5w x 1.6h, sill 0.85
    const LX = -ROOM.w / 2;
    const WIN = { w: 1.5, h: 1.6, sill: 0.85, cz: -0.9 };
    const zTop = WIN.cz + WIN.w / 2, zBot = WIN.cz - WIN.w / 2;
    // segments: left-of-window (z from zTop..d/2), right (from -d/2..zBot), above, below
    function lwSeg(wd, ht, cy, cz) {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(wd, ht), wallMat);
      m.position.set(LX, cy, cz);
      m.rotation.y = Math.PI / 2;
      m.receiveShadow = true;
      scene.add(m);
    }
    lwSeg(ROOM.d / 2 - zTop, ROOM.h, ROOM.h / 2, (zTop + ROOM.d / 2) / 2);
    lwSeg(zBot + ROOM.d / 2, ROOM.h, ROOM.h / 2, (zBot - ROOM.d / 2) / 2);
    lwSeg(WIN.w, ROOM.h - WIN.sill - WIN.h, (WIN.sill + WIN.h + ROOM.h) / 2, WIN.cz);
    lwSeg(WIN.w, WIN.sill, WIN.sill / 2, WIN.cz);
    W.windowCenter = new THREE.Vector3(LX, WIN.sill + WIN.h / 2, WIN.cz);

    /* ----- window frame + open casement ----- */
    const frameMat = new THREE.MeshStandardMaterial({ color: 0xe6dcc8, roughness: 0.7 });
    const frameGrp = new THREE.Group();
    const fd = 0.07, ft = 0.06;
    function bar(w_, h_, d_, x_, y_, z_) {
      const b = new THREE.Mesh(new THREE.BoxGeometry(w_, h_, d_), frameMat);
      b.position.set(x_, y_, z_);
      b.castShadow = true;
      frameGrp.add(b);
      return b;
    }
    const wy = WIN.sill + WIN.h / 2;
    // outer frame (frame plane faces +x into room; local axes: x depth, z along wall)
    bar(fd, WIN.h + ft, ft, 0, 0, WIN.w / 2);
    bar(fd, WIN.h + ft, ft, 0, 0, -WIN.w / 2);
    bar(fd, ft, WIN.w + ft, 0, WIN.h / 2, 0);
    bar(fd, ft, WIN.w + ft, 0, -WIN.h / 2, 0);
    // sill ledge
    const sill = bar(0.16, 0.04, WIN.w + 0.2, 0.06, -WIN.h / 2 - 0.02, 0);
    sill.receiveShadow = true;
    frameGrp.position.set(LX, wy, WIN.cz);
    scene.add(frameGrp);

    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0xfff4e0, roughness: 0.04, metalness: 0, transparent: true, opacity: 0.1,
      envMapIntensity: 1.6,
    });
    // closed casement (far half, toward -z side of frame)
    const caseGrp1 = new THREE.Group();
    const c1glass = new THREE.Mesh(new THREE.PlaneGeometry(WIN.w / 2 - 0.06, WIN.h - 0.08), glassMat);
    c1glass.rotation.y = Math.PI / 2;
    caseGrp1.add(c1glass);
    const cm = frameMat.clone();
    function caseBar(grp, w_, h_, d_, x_, y_, z_) {
      const b = new THREE.Mesh(new THREE.BoxGeometry(w_, h_, d_), cm);
      b.position.set(x_, y_, z_); b.castShadow = true; grp.add(b);
    }
    const cw = WIN.w / 2;
    for (const grp of [caseGrp1]) {
      caseBar(grp, 0.045, WIN.h, 0.045, 0, 0, cw / 2 - 0.02);
      caseBar(grp, 0.045, WIN.h, 0.045, 0, 0, -cw / 2 + 0.02);
      caseBar(grp, 0.045, 0.045, cw, 0, WIN.h / 2 - 0.02, 0);
      caseBar(grp, 0.045, 0.045, cw, 0, -WIN.h / 2 + 0.02, 0);
      caseBar(grp, 0.045, 0.045, cw, 0, 0.12, 0); // middle rail
    }
    caseGrp1.position.set(LX + 0.01, wy, WIN.cz - cw / 2);
    scene.add(caseGrp1);
    // open casement — hinged at near edge (+z side), swung outward
    const caseGrp2 = new THREE.Group();
    const inner2 = new THREE.Group();
    const c2glass = c1glass.clone();
    inner2.add(c2glass);
    caseBar(inner2, 0.045, WIN.h, 0.045, 0, 0, cw / 2 - 0.02);
    caseBar(inner2, 0.045, WIN.h, 0.045, 0, 0, -cw / 2 + 0.02);
    caseBar(inner2, 0.045, 0.045, cw, 0, WIN.h / 2 - 0.02, 0);
    caseBar(inner2, 0.045, 0.045, cw, 0, -WIN.h / 2 + 0.02, 0);
    caseBar(inner2, 0.045, 0.045, cw, 0, 0.12, 0);
    inner2.position.z = -cw / 2; // hinge at +z edge
    caseGrp2.add(inner2);
    caseGrp2.position.set(LX - 0.02, wy, WIN.cz + cw);
    caseGrp2.rotation.y = -1.15; // swung open, outward
    scene.add(caseGrp2);

    /* ----- outside: warm sky backdrop + sun glow ----- */
    const sky = new THREE.Mesh(new THREE.PlaneGeometry(16, 12), new THREE.MeshBasicMaterial({
      map: tex(skyCanvas()), fog: false,
    }));
    sky.position.set(LX - 5.5, 2.6, WIN.cz);
    sky.rotation.y = Math.PI / 2;
    scene.add(sky);
    const sunGlow = new THREE.Sprite(new THREE.SpriteMaterial({
      map: tex(glowSprite()), color: 0xffedc8, transparent: true, opacity: 0.95,
      blending: THREE.AdditiveBlending, depthWrite: false, fog: false,
    }));
    sunGlow.scale.set(3.2, 3.2, 1);
    sunGlow.position.set(LX - 4.8, 2.5, WIN.cz - 0.4);
    scene.add(sunGlow);

    /* ----- sheer curtain ----- */
    const curtGeo = new THREE.PlaneGeometry(0.55, 2.05, 10, 26);
    const curtMat = new THREE.MeshStandardMaterial({
      color: 0xf7ecd8, transparent: true, opacity: 0.34, side: THREE.DoubleSide,
      roughness: 0.9, depthWrite: false,
    });
    const curtain = new THREE.Mesh(curtGeo, curtMat);
    curtain.position.set(LX + 0.14, WIN.sill + WIN.h / 2 + 0.18, WIN.cz + WIN.w / 2 + 0.12);
    curtain.rotation.y = Math.PI / 2;
    scene.add(curtain);
    const curtBase = curtGeo.attributes.position.array.slice();
    W.updateCurtain = (t) => {
      const p = curtGeo.attributes.position;
      for (let i = 0; i < p.count; i++) {
        const bx = curtBase[i * 3], by = curtBase[i * 3 + 1];
        const sway = (1 - (by + 1.025) / 2.05); // more sway at bottom
        p.array[i * 3 + 2] = Math.sin(t * 0.7 + bx * 4 + by * 2.2) * 0.05 * sway
          + Math.sin(t * 0.31 + by * 3.1) * 0.03 * sway;
      }
      p.needsUpdate = true;
      curtGeo.computeVertexNormals();
    };

    /* ----- volumetric beams ----- */
    const beams = new THREE.Group();
    const sunDir = new THREE.Vector3().subVectors(sun.target.position, sun.position).normalize();
    for (let i = 0; i < 3; i++) {
      const bm = beamMaterial(0.05 + i * 0.014);
      const plane = new THREE.Mesh(new THREE.PlaneGeometry(4.6, WIN.w * (1 + i * 0.14)), bm);
      // orient: beam quad runs from window along sunDir; plane's local +x is length
      const start = new THREE.Vector3(LX + 0.05, wy + 0.1 - i * 0.12, WIN.cz + (i - 1) * 0.05);
      const mid = start.clone().addScaledVector(sunDir, 2.3);
      plane.position.copy(mid);
      plane.lookAt(mid.clone().add(new THREE.Vector3(0, 1, 0).cross(sunDir)));
      // build orientation manually: x along sunDir, plane normal horizontal-ish
      const xAxis = sunDir.clone();
      const zAxis = new THREE.Vector3(0, 1, 0).clone().cross(xAxis).normalize();
      const yAxis = xAxis.clone().cross(zAxis).normalize();
      const mtx = new THREE.Matrix4().makeBasis(xAxis, yAxis, zAxis);
      plane.setRotationFromMatrix(mtx);
      plane.rotateX(Math.PI / 2 + (i - 1) * 0.06);
      plane.material.uniforms.uColor.value = new THREE.Color(0xffd9a0);
      beams.add(plane);
      if (!W.beamMats) W.beamMats = [];
      W.beamMats.push(bm);
    }
    scene.add(beams);

    /* ----- dust ----- */
    const beamDust = dustPoints(PERF.mobile ? 260 : 520, new THREE.Box3(
      new THREE.Vector3(-3.1, 0.35, -1.8), new THREE.Vector3(0.6, 2.35, 0.4)
    ), 0xffe3b8, 3.2, 0.5);
    scene.add(beamDust);
    const roomDust = dustPoints(PERF.mobile ? 120 : 260, new THREE.Box3(
      new THREE.Vector3(-2.6, 0.2, -2.4), new THREE.Vector3(2.6, 2.6, 2.4)
    ), 0xffe9cf, 2.4, 0.2);
    scene.add(roomDust);
    W.dustMats = [beamDust.material, roomDust.material];

    /* ----- soft contact shadow where walls meet the floor ----- */
    const [gc, gx] = canv(16, 64);
    const gg = gx.createLinearGradient(0, 64, 0, 0);
    gg.addColorStop(0, 'rgba(0,0,0,0.85)');
    gg.addColorStop(1, 'rgba(0,0,0,0)');
    gx.fillStyle = gg; gx.fillRect(0, 0, 16, 64);
    const stripTex = new THREE.CanvasTexture(gc);
    const stripMat = new THREE.MeshBasicMaterial({
      map: stripTex, transparent: true, opacity: 0.3, color: 0x241407, depthWrite: false,
    });
    function baseStrip(len, px, pz, ry) {
      const s = new THREE.Mesh(new THREE.PlaneGeometry(len, 0.15), stripMat);
      s.position.set(px, 0.075, pz);
      s.rotation.y = ry;
      s.renderOrder = 1;
      scene.add(s);
    }
    baseStrip(ROOM.w, 0, -ROOM.d / 2 + 0.006, 0);
    baseStrip(ROOM.d, -ROOM.w / 2 + 0.006, 0, Math.PI / 2);
    baseStrip(ROOM.d, ROOM.w / 2 - 0.006, 0, -Math.PI / 2);

    /* ----- rug ----- */
    const [rc, rx] = canv(512, 512);
    rx.fillStyle = '#b7a189'; rx.fillRect(0, 0, 512, 512);
    for (let i = 0; i < 14000; i++) {
      rx.fillStyle = Math.random() < 0.5 ? 'rgba(130,106,80,0.12)' : 'rgba(222,206,182,0.1)';
      rx.fillRect(Math.random() * 512, Math.random() * 512, rnd(1, 2.4), rnd(1, 2.4));
    }
    rx.strokeStyle = 'rgba(122,94,66,0.4)'; rx.lineWidth = 8;
    rx.beginPath(); rx.arc(256, 256, 238, 0, Math.PI * 2); rx.stroke();
    rx.lineWidth = 2.5;
    rx.beginPath(); rx.arc(256, 256, 222, 0, Math.PI * 2); rx.stroke();
    const rug = new THREE.Mesh(new THREE.CircleGeometry(1.2, 48), new THREE.MeshStandardMaterial({
      map: tex(rc), roughness: 0.98,
    }));
    rug.rotation.x = -Math.PI / 2;
    rug.position.set(0.1, 0.004, 0.42);
    rug.receiveShadow = true;
    scene.add(rug);

    /* ----- desk ----- */
    const woodMat = new THREE.MeshPhysicalMaterial({
      map: tex(woodTexture(), true, [1, 1]), roughness: 0.4, metalness: 0.02,
      clearcoat: 0.28, clearcoatRoughness: 0.42, envMapIntensity: 0.75,
    });
    const desk = new THREE.Group();
    const top = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.045, 0.85), woodMat);
    top.position.y = 0.7375;
    top.castShadow = true; top.receiveShadow = true;
    desk.add(top);
    const legMat = new THREE.MeshStandardMaterial({
      map: tex(woodTexture('#5d4029', '#40291a', '#755338'), true, [0.5, 2]), roughness: 0.5,
    });
    for (const [lx, lz] of [[-0.76, -0.34], [0.76, -0.34], [-0.76, 0.34], [0.76, 0.34]]) {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.02, 0.715, 12), legMat);
      leg.position.set(lx, 0.3575, lz);
      leg.castShadow = true;
      desk.add(leg);
    }
    // slim apron
    const apron1 = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.07, 0.02), legMat);
    apron1.position.set(0, 0.68, -0.32); desk.add(apron1);
    const apron2 = apron1.clone(); apron2.position.z = 0.32; desk.add(apron2);
    desk.position.set(0, 0, 0);
    scene.add(desk);
    const deskAO = aoDecal(2.4, 1.4, 0.3);
    deskAO.position.set(0, 0.006, 0);
    scene.add(deskAO);
    const DESK_Y = 0.76;
    W.DESK_Y = DESK_Y;

    /* ----- envelope ----- */
    const envPaper = new THREE.MeshStandardMaterial({
      map: tex(paperCanvas('#f2e8d5', '#d6c6a8', 512, 512, 3400)), roughness: 0.82, envMapIntensity: 0.5,
    });
    const envelope = new THREE.Group();
    const EW = 0.225, ED = 0.16, ET = 0.007;
    const envBody = new THREE.Mesh(new THREE.BoxGeometry(EW, ET, ED), envPaper);
    envBody.position.y = ET / 2;
    envBody.castShadow = true; envBody.receiveShadow = true;
    envelope.add(envBody);
    // flap: triangle hinged at back edge, lying closed on top
    const flapShape = new THREE.Shape();
    flapShape.moveTo(-EW / 2, 0);
    flapShape.lineTo(EW / 2, 0);
    flapShape.lineTo(0.012, ED * 0.62);
    flapShape.lineTo(-0.012, ED * 0.62);
    flapShape.closePath();
    const flapGeo = new THREE.ShapeGeometry(flapShape);
    flapGeo.rotateX(-Math.PI / 2); // now lies in xz, extends +z from hinge
    const flap = new THREE.Mesh(flapGeo, new THREE.MeshStandardMaterial({
      map: envPaper.map, roughness: 0.82, side: THREE.DoubleSide, envMapIntensity: 0.5,
      color: 0xf0e5cf, // a shade deeper so the open flap reads against the wall
    }));
    flap.castShadow = true;
    const flapHinge = new THREE.Group();
    flapHinge.position.set(0, ET + 0.0006, -ED / 2);
    flapHinge.add(flap);
    envelope.add(flapHinge);
    W.flapHinge = flapHinge;

    // wax seal on flap tip
    const sealBump = new THREE.CanvasTexture(sealBumpCanvas());
    const waxMat = new THREE.MeshPhysicalMaterial({
      color: 0x7d2b24, roughness: 0.38, metalness: 0, clearcoat: 0.5, clearcoatRoughness: 0.4,
      bumpMap: sealBump, bumpScale: 1.6,
    });
    const sealWhole = new THREE.Mesh(new THREE.CylinderGeometry(0.021, 0.0225, 0.005, 28), waxMat);
    sealWhole.position.set(0, 0.003, ED * 0.52);
    sealWhole.castShadow = true;
    flapHinge.add(sealWhole);
    W.sealWhole = sealWhole;
    // pre-split halves (hidden)
    const halfGeoL = new THREE.CylinderGeometry(0.021, 0.0225, 0.005, 14, 1, false, Math.PI / 2, Math.PI);
    const halfGeoR = new THREE.CylinderGeometry(0.021, 0.0225, 0.005, 14, 1, false, -Math.PI / 2, Math.PI);
    const sealL = new THREE.Mesh(halfGeoL, waxMat);
    const sealR = new THREE.Mesh(halfGeoR, waxMat);
    sealL.visible = sealR.visible = false;
    sealL.castShadow = sealR.castShadow = true;
    flapHinge.add(sealL, sealR);
    W.sealL = sealL; W.sealR = sealR;
    W.sealHome = sealWhole.position.clone();

    envelope.position.set(-0.14, DESK_Y + 0.001, 0.02);
    envelope.rotation.y = -0.22;
    scene.add(envelope);
    W.envelope = envelope;
    const envAO = aoDecal(0.34, 0.26, 0.5);
    envAO.position.set(-0.14, DESK_Y + 0.0015, 0.02);
    envAO.rotation.z = -0.22;
    scene.add(envAO);

    /* ----- letter (trifold) ----- */
    const writing = tex(handwritingCanvas());
    const letterRoot = new THREE.Group();
    const LW = 0.16, LD = 0.075;
    function panel(vlo, vhi) {
      const g = new THREE.PlaneGeometry(LW, LD);
      g.rotateX(-Math.PI / 2);
      g.translate(0, 0, LD / 2);
      const uv = g.attributes.uv;
      for (let i = 0; i < uv.count; i++) uv.setY(i, vlo + uv.getY(i) * (vhi - vlo));
      const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({
        map: writing, roughness: 0.85, side: THREE.DoubleSide, envMapIntensity: 0.5,
      }));
      m.castShadow = true;
      return m;
    }
    const p1 = panel(2 / 3, 1);
    letterRoot.add(p1);
    const hinge2 = new THREE.Group();
    hinge2.position.set(0, 0.0012, LD);
    const p2 = panel(1 / 3, 2 / 3);
    hinge2.add(p2);
    letterRoot.add(hinge2);
    const hinge3 = new THREE.Group();
    hinge3.position.set(0, 0.0012, LD);
    const p3 = panel(0, 1 / 3);
    hinge3.add(p3);
    hinge2.add(hinge3);
    hinge2.rotation.x = Math.PI - 0.06;
    hinge3.rotation.x = Math.PI - 0.06;
    letterRoot.position.set(-0.14, DESK_Y + 0.004, 0.02);
    letterRoot.rotation.y = -0.22;
    letterRoot.visible = false;
    scene.add(letterRoot);
    W.letterRoot = letterRoot; W.hinge2 = hinge2; W.hinge3 = hinge3;

    /* ----- fountain pen ----- */
    const pen = new THREE.Group();
    const lacquer = new THREE.MeshPhysicalMaterial({
      color: 0x241512, roughness: 0.16, metalness: 0.1, clearcoat: 1, clearcoatRoughness: 0.08,
    });
    const goldMat = new THREE.MeshStandardMaterial({ color: 0xc9a05c, roughness: 0.28, metalness: 1 });
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.0062, 0.0055, 0.105, 20), lacquer);
    body.rotation.z = Math.PI / 2;
    pen.add(body);
    const capEnd = new THREE.Mesh(new THREE.SphereGeometry(0.0062, 16, 12), lacquer);
    capEnd.position.x = -0.0525; capEnd.scale.x = 0.7; pen.add(capEnd);
    const tail = new THREE.Mesh(new THREE.SphereGeometry(0.0055, 16, 12), lacquer);
    tail.position.x = 0.0525; tail.scale.x = 1.4; pen.add(tail);
    const band = new THREE.Mesh(new THREE.CylinderGeometry(0.0064, 0.0064, 0.004, 20), goldMat);
    band.rotation.z = Math.PI / 2; band.position.x = -0.012; pen.add(band);
    const clip = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.0022, 0.0032), goldMat);
    clip.position.set(-0.032, 0.0075, 0); pen.add(clip);
    const clipBall = new THREE.Mesh(new THREE.SphereGeometry(0.0026, 10, 8), goldMat);
    clipBall.position.set(-0.015, 0.0068, 0); pen.add(clipBall);
    pen.traverse((o) => { if (o.isMesh) o.castShadow = true; });
    pen.position.set(0.34, DESK_Y + 0.0065, -0.16);
    pen.rotation.y = 0.6;
    pen.rotation.x = 0.0;
    scene.add(pen);
    const penAO = aoDecal(0.17, 0.05, 0.45);
    penAO.position.set(0.34, DESK_Y + 0.0012, -0.16);
    penAO.rotation.z = 0.6;
    scene.add(penAO);

    /* ----- dried flowers ----- */
    const dried = new THREE.Group();
    const stemMat = new THREE.MeshStandardMaterial({ color: 0x77603f, roughness: 0.95 });
    const headColors = [0x9c8078, 0xa8905e, 0x83907a, 0x9c7a70, 0x8f7355];
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 0.9 - 0.7;
      const curve = new THREE.QuadraticBezierCurve3(
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(Math.sin(a) * 0.05, 0.09, Math.cos(a) * 0.03),
        new THREE.Vector3(Math.sin(a) * 0.11 + rnd(-0.01, 0.01), 0.15 + (i % 3) * 0.03, Math.cos(a) * 0.07),
      );
      const stem = new THREE.Mesh(new THREE.TubeGeometry(curve, 8, 0.0013, 5), stemMat);
      stem.castShadow = true;
      dried.add(stem);
      const headPos = curve.getPoint(1);
      const head = new THREE.Group();
      const hm = new THREE.MeshStandardMaterial({ color: headColors[i % headColors.length], roughness: 1 });
      const nPet = 7;
      for (let p = 0; p < nPet; p++) {
        const pet = new THREE.Mesh(new THREE.SphereGeometry(0.0052, 7, 5), hm);
        pet.scale.set(0.5, 1.25, 0.26);
        const pa = (p / nPet) * Math.PI * 2 + i;
        pet.position.set(Math.cos(pa) * 0.0045, 0.005, Math.sin(pa) * 0.0045);
        pet.rotation.set(Math.sin(pa) * 0.85, 0, Math.cos(pa) * -0.85);
        head.add(pet);
      }
      head.position.copy(headPos);
      head.rotation.set(rnd(-0.3, 0.3), rnd(0, 3), rnd(-0.3, 0.3));
      head.castShadow = true;
      dried.add(head);
    }
    // twine wrap
    const twine = new THREE.Mesh(new THREE.TorusGeometry(0.011, 0.0028, 8, 20), new THREE.MeshStandardMaterial({ color: 0xa8845c, roughness: 1 }));
    twine.rotation.x = Math.PI / 2 - 0.3;
    twine.position.y = 0.035;
    dried.add(twine);
    dried.position.set(-0.58, DESK_Y, -0.2);
    dried.rotation.z = 0.42;
    dried.rotation.y = 0.8;
    scene.add(dried);
    const driedAO = aoDecal(0.22, 0.14, 0.4);
    driedAO.position.set(-0.62, DESK_Y + 0.0012, -0.18);
    scene.add(driedAO);

    /* ----- bookshelf ----- */
    const shelf = new THREE.Group();
    const shelfWood = new THREE.MeshStandardMaterial({
      map: tex(woodTexture('#54381f', '#3a2413', '#6d4c2c'), true, [2, 1]), roughness: 0.55,
    });
    const SH = { w: 2.1, h: 2.05, d: 0.26 };
    const sideL = new THREE.Mesh(new THREE.BoxGeometry(0.04, SH.h, SH.d), shelfWood);
    sideL.position.set(-SH.w / 2, SH.h / 2, 0);
    const sideR = sideL.clone(); sideR.position.x = SH.w / 2;
    const back = new THREE.Mesh(new THREE.BoxGeometry(SH.w, SH.h, 0.016), shelfWood);
    back.position.set(0, SH.h / 2, -SH.d / 2 + 0.008);
    shelf.add(sideL, sideR, back);
    const shelfYs = [0.12, 0.58, 1.04, 1.5, 1.96];
    for (const sy of shelfYs) {
      const b = new THREE.Mesh(new THREE.BoxGeometry(SH.w, 0.035, SH.d), shelfWood);
      b.position.y = sy;
      b.castShadow = true; b.receiveShadow = true;
      shelf.add(b);
    }
    // books — instanced, muted spines
    const bookGeo = new THREE.BoxGeometry(1, 1, 1);
    const bookMat = new THREE.MeshStandardMaterial({ roughness: 0.94 });
    const palette = [0x74473a, 0x848f78, 0x4e4a30, 0x967a55, 0x5e4550, 0xa89a82, 0x4d555c, 0x6e332c, 0x77603f, 0x3d463a];
    const bookCount = 76;
    const books = new THREE.InstancedMesh(bookGeo, bookMat, bookCount);
    books.castShadow = true;
    const dummy = new THREE.Object3D();
    let bi = 0;
    for (let row = 0; row < 4 && bi < bookCount; row++) {
      let bx = -SH.w / 2 + 0.07 + Math.random() * 0.05;
      const baseY = shelfYs[row] + 0.0175;
      const rowFill = 0.55 + Math.random() * 0.35;
      while (bx < -SH.w / 2 + SH.w * rowFill && bi < bookCount) {
        const bw = rnd(0.02, 0.048);
        const bh = rnd(0.16, 0.27);
        const lean = Math.random() < 0.09 ? rnd(-0.1, 0.1) : 0;
        dummy.position.set(bx + bw / 2, baseY + bh / 2, rnd(-0.02, 0.015));
        dummy.rotation.set(0, rnd(-0.02, 0.02), lean);
        dummy.scale.set(bw, bh, rnd(0.17, 0.21));
        dummy.updateMatrix();
        books.setMatrixAt(bi, dummy.matrix);
        books.setColorAt(bi, new THREE.Color(palette[Math.floor(Math.random() * palette.length)]).multiplyScalar(rnd(0.8, 1.1)));
        bx += bw + rnd(0.001, 0.01);
        bi++;
      }
    }
    // fill any leftover instances out of sight
    while (bi < bookCount) {
      dummy.position.set(0, -5, 0); dummy.scale.setScalar(0.001); dummy.updateMatrix();
      books.setMatrixAt(bi, dummy.matrix); bi++;
    }
    books.instanceMatrix.needsUpdate = true;
    if (books.instanceColor) books.instanceColor.needsUpdate = true;
    shelf.add(books);
    // horizontal stack + tiny vase on a shelf
    const stack = new THREE.Group();
    for (let s = 0; s < 3; s++) {
      const b = new THREE.Mesh(bookGeo, new THREE.MeshStandardMaterial({
        color: palette[(s * 3 + 1) % palette.length], roughness: 0.85,
      }));
      b.scale.set(0.16 - s * 0.015, 0.03, 0.2);
      b.position.set(0.72, shelfYs[2] + 0.0175 + 0.015 + s * 0.031, 0);
      b.rotation.y = rnd(-0.08, 0.08);
      b.castShadow = true;
      stack.add(b);
    }
    shelf.add(stack);
    const vase = new THREE.Mesh(
      new THREE.LatheGeometry([
        new THREE.Vector2(0.015, 0), new THREE.Vector2(0.028, 0.02), new THREE.Vector2(0.024, 0.055),
        new THREE.Vector2(0.011, 0.075), new THREE.Vector2(0.014, 0.095),
      ], 16),
      new THREE.MeshPhysicalMaterial({ color: 0x9aa88c, roughness: 0.3, clearcoat: 0.6 })
    );
    vase.position.set(0.45, shelfYs[3] + 0.0175, 0.01);
    vase.castShadow = true;
    shelf.add(vase);
    shelf.position.set(1.15, 0, -ROOM.d / 2 + SH.d / 2 + 0.02);
    scene.add(shelf);

    /* ----- plant ----- */
    const plant = new THREE.Group();
    const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.115, 0.3, 20), new THREE.MeshStandardMaterial({
      color: 0x8a5138, roughness: 0.9,
    }));
    pot.position.y = 0.15;
    pot.castShadow = true;
    plant.add(pot);
    const potRim = new THREE.Mesh(new THREE.CylinderGeometry(0.158, 0.15, 0.045, 20), pot.material);
    potRim.position.y = 0.285; plant.add(potRim);
    const soil = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.02, 20), new THREE.MeshStandardMaterial({ color: 0x2e2016, roughness: 1 }));
    soil.position.y = 0.295; plant.add(soil);
    const leafMat = new THREE.MeshStandardMaterial({
      color: 0x5c684c, roughness: 0.72, side: THREE.DoubleSide, emissive: 0x101808, emissiveIntensity: 0.25,
    });
    const leafShape = new THREE.Shape();
    leafShape.moveTo(0, 0);
    leafShape.bezierCurveTo(0.06, 0.02, 0.1, 0.1, 0.06, 0.2);
    leafShape.bezierCurveTo(0.03, 0.26, -0.03, 0.26, -0.06, 0.2);
    leafShape.bezierCurveTo(-0.1, 0.1, -0.06, 0.02, 0, 0);
    const leafGeo = new THREE.ShapeGeometry(leafShape, 8);
    const stemMat2 = new THREE.MeshStandardMaterial({ color: 0x4a5d3a, roughness: 0.7 });
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2 + rnd(-0.2, 0.2);
      const lean = rnd(0.35, 0.85);
      const hgt = rnd(0.35, 0.75);
      const curve = new THREE.QuadraticBezierCurve3(
        new THREE.Vector3(0, 0.3, 0),
        new THREE.Vector3(Math.cos(a) * lean * 0.25, 0.3 + hgt * 0.75, Math.sin(a) * lean * 0.25),
        new THREE.Vector3(Math.cos(a) * lean * 0.42, 0.3 + hgt, Math.sin(a) * lean * 0.42),
      );
      const stem = new THREE.Mesh(new THREE.TubeGeometry(curve, 10, 0.006, 6), stemMat2);
      stem.castShadow = true;
      plant.add(stem);
      const leaf = new THREE.Mesh(leafGeo, leafMat);
      const end = curve.getPoint(1);
      const tan = curve.getTangent(1);
      leaf.position.copy(end);
      leaf.scale.setScalar(rnd(0.85, 1.5));
      leaf.lookAt(end.clone().add(tan));
      leaf.rotateX(rnd(-0.4, 0.1));
      leaf.rotateZ(rnd(-0.4, 0.4));
      leaf.castShadow = true;
      plant.add(leaf);
    }
    plant.position.set(2.55, 0, -2.05);
    scene.add(plant);
    const plantAO = aoDecal(0.5, 0.5, 0.4);
    plantAO.position.set(2.55, 0.005, -2.05);
    scene.add(plantAO);

    /* ----- framed art on back wall ----- */
    const artFrame = new THREE.Group();
    const fMat = new THREE.MeshStandardMaterial({ color: 0x8a6b3a, roughness: 0.4, metalness: 0.55 });
    const fw = 0.56, fh = 0.74, bw2 = 0.035;
    for (const [w_, h_, x_, y_] of [[fw, bw2, 0, fh / 2], [fw, bw2, 0, -fh / 2], [bw2, fh, -fw / 2, 0], [bw2, fh, fw / 2, 0]]) {
      const b = new THREE.Mesh(new THREE.BoxGeometry(w_, h_, 0.03), fMat);
      b.position.set(x_, y_, 0);
      b.castShadow = true;
      artFrame.add(b);
    }
    const [ac, ax] = canv(256, 340);
    const ag = ax.createLinearGradient(0, 0, 0, 340);
    ag.addColorStop(0, '#e8c288'); ag.addColorStop(0.55, '#c98a5a'); ag.addColorStop(1, '#7d5a42');
    ax.fillStyle = ag; ax.fillRect(0, 0, 256, 340);
    ax.fillStyle = 'rgba(255,240,210,0.5)';
    ax.beginPath(); ax.arc(128, 118, 44, 0, Math.PI * 2); ax.fill();
    ax.filter = 'blur(14px)'; ax.drawImage(ac, 0, 0); ax.filter = 'none';
    const art = new THREE.Mesh(new THREE.PlaneGeometry(fw - 0.05, fh - 0.05), new THREE.MeshStandardMaterial({
      map: tex(ac), roughness: 0.9,
    }));
    art.position.z = -0.005;
    artFrame.add(art);
    artFrame.position.set(-1.5, 1.62, -ROOM.d / 2 + 0.03);
    scene.add(artFrame);

    /* ============================================================
       PAPER AIRPLANE
       ============================================================ */
    const planeGrp = new THREE.Group();
    const planePaperC = paperCanvas('#fdfaf2', '#e3d9c4', 256, 256, 1200);
    {
      // crease shading along the fold (uv v=0 → canvas bottom)
      const px = planePaperC.getContext('2d');
      const grd = px.createLinearGradient(0, 256, 0, 196);
      grd.addColorStop(0, 'rgba(130,110,80,0.34)');
      grd.addColorStop(1, 'rgba(130,110,80,0)');
      px.fillStyle = grd;
      px.fillRect(0, 196, 256, 60);
    }
    const planePaper = new THREE.MeshStandardMaterial({
      map: tex(planePaperC),
      roughness: 0.75, side: THREE.DoubleSide, envMapIntensity: 0.6,
    });
    // crease-shaded copy for the keel
    const keelPaper = planePaper.clone();
    keelPaper.color = new THREE.Color(0xf0ead9);

    function quadGeo(a, b, c2, d2) {
      // two triangles a-b-c, a-c-d with soft normals
      const g = new THREE.BufferGeometry();
      const v = new Float32Array([...a, ...b, ...c2, ...a, ...c2, ...d2]);
      g.setAttribute('position', new THREE.BufferAttribute(v, 3));
      g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array([0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1]), 2));
      g.computeVertexNormals();
      return g;
    }
    function triGeo(a, b, c2, uvs = [0, 0, 1, 0, 0.5, 1]) {
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(new Float32Array([...a, ...b, ...c2]), 3));
      g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(uvs), 2));
      g.computeVertexNormals();
      return g;
    }
    // nose +z, keel bottom at y=0 — raised wing tips so the dart reads in silhouette
    const NOSE = [0, 0.0265, 0.105];
    const KTOP = 0.0265;
    const wingL = new THREE.Mesh(triGeo(NOSE, [0, KTOP, -0.105], [-0.062, 0.0455, -0.102]), planePaper);
    const wingR = new THREE.Mesh(triGeo(NOSE, [0.0645, 0.0475, -0.102], [0, KTOP, -0.105]), planePaper);
    const keelL = new THREE.Mesh(quadGeo([-0.0012, KTOP, 0.105], [-0.0012, 0.0, 0.052], [-0.0012, 0.0, -0.105], [-0.0012, KTOP, -0.105]), keelPaper);
    const keelR = new THREE.Mesh(quadGeo([0.0012, KTOP, 0.105], [0.0012, KTOP, -0.105], [0.0012, 0.0, -0.105], [0.0012, 0.0, 0.052]), keelPaper);
    for (const m of [wingL, wingR, keelL, keelR]) { m.castShadow = true; planeGrp.add(m); }
    planeGrp.scale.setScalar(1.18);
    planeGrp.visible = false;
    scene.add(planeGrp);
    W.plane = planeGrp;
    W.planeWings = { L: wingL, R: wingR };

    /* ----- flight path ----- */
    W.flightCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-4.9, 2.1, -1.35),
      new THREE.Vector3(-3.15, 1.74, -0.92),
      new THREE.Vector3(-1.7, 1.62, -1.45),
      new THREE.Vector3(0.5, 1.42, -1.75),
      new THREE.Vector3(1.9, 1.2, -1.15),
      new THREE.Vector3(2.15, 1.0, 0.55),
      new THREE.Vector3(0.95, 0.82, 1.55),
      new THREE.Vector3(-0.55, 0.92, 1.25),
      new THREE.Vector3(-1.0, 1.0, 0.25),
      new THREE.Vector3(-0.5, 0.9, -0.42),
      new THREE.Vector3(-0.1, 0.83, -0.3),
      new THREE.Vector3(0.17, 0.7635, 0.1),
    ], false, 'catmullrom', 0.28);
    W.landPos = new THREE.Vector3(0.17, 0.7615, 0.1);
    W.landHeading = Math.atan2(0.27, 0.4);

    // exit path for the finale
    W.exitCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.17, 0.98, 0.1),
      new THREE.Vector3(-0.5, 1.2, 0.55),
      new THREE.Vector3(-1.6, 1.5, 0.15),
      new THREE.Vector3(-2.6, 1.68, -0.55),
      new THREE.Vector3(-3.3, 1.78, -0.95),
      new THREE.Vector3(-5.2, 2.3, -1.5),
    ], false, 'catmullrom', 0.3);

    /* ----- landing poof ----- */
    const poofGeo = new THREE.BufferGeometry();
    const poofN = 14;
    poofGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(poofN * 3), 3));
    poofGeo.setAttribute('aSeed', new THREE.BufferAttribute(new Float32Array(poofN).map(() => Math.random() * 100), 1));
    const poof = new THREE.Points(poofGeo, new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: { uT: { value: 2 }, uOrigin: { value: new THREE.Vector3() }, uSize: { value: 5 * Math.min(devicePixelRatio, 2) } },
      vertexShader: `
        attribute float aSeed; uniform float uT; uniform vec3 uOrigin; uniform float uSize;
        varying float vA;
        void main(){
          float a = aSeed*6.283; float r = uT*(0.05+fract(aSeed*7.7)*0.06);
          vec3 p = uOrigin + vec3(cos(a)*r, uT*0.055*(0.4+fract(aSeed*3.3)), sin(a)*r*0.7);
          vec4 mv = modelViewMatrix*vec4(p,1.0);
          gl_PointSize = uSize*(1.0/-mv.z);
          vA = max(0.0, 1.0-uT*1.4);
          gl_Position = projectionMatrix*mv;
        }`,
      fragmentShader: `
        varying float vA;
        void main(){
          float m = smoothstep(0.5,0.1,length(gl_PointCoord-0.5));
          gl_FragColor = vec4(1.0,0.93,0.8, m*vA*0.5);
        }`,
    }));
    scene.add(poof);
    W.poof = poof;

    /* ----- paper-mote trail behind the plane ----- */
    const trailN = 40;
    const trailGeo = new THREE.BufferGeometry();
    trailGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(trailN * 3).fill(999), 3));
    trailGeo.setAttribute('aBirth', new THREE.BufferAttribute(new Float32Array(trailN).fill(-99), 1));
    const trailMat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false,
      uniforms: { uNow: { value: 0 }, uSize: { value: 4.5 * Math.min(devicePixelRatio, 2) } },
      vertexShader: `
        attribute float aBirth; uniform float uNow; uniform float uSize;
        varying float vA;
        void main(){
          float age = uNow - aBirth;
          vec3 p = position + vec3(0.0, -age*0.03, 0.0);
          vec4 mv = modelViewMatrix*vec4(p,1.0);
          gl_PointSize = uSize*(1.0/-mv.z);
          vA = max(0.0, 1.0-age*0.9);
          gl_Position = projectionMatrix*mv;
        }`,
      fragmentShader: `
        varying float vA;
        void main(){
          float m = smoothstep(0.5,0.15,length(gl_PointCoord-0.5));
          gl_FragColor = vec4(1.0,0.97,0.9, m*vA*0.55);
        }`,
    });
    const trail = new THREE.Points(trailGeo, trailMat);
    trail.frustumCulled = false;
    scene.add(trail);
    let trailIdx = 0;
    W.emitTrail = (pos, now) => {
      const p = trailGeo.attributes.position, b = trailGeo.attributes.aBirth;
      p.setXYZ(trailIdx, pos.x + rnd(-0.02, 0.02), pos.y + rnd(-0.015, 0.015), pos.z + rnd(-0.02, 0.02));
      b.setX(trailIdx, now);
      p.needsUpdate = true; b.needsUpdate = true;
      trailIdx = (trailIdx + 1) % trailN;
    };
    W.trailMat = trailMat;

    /* ============================================================
       MAGIC — butterflies, petals, sparkles (dormant until Scene 5)
       ============================================================ */
    const wingTex = tex(butterflyWingCanvas());
    const glowTex = tex(glowSprite('rgba(255,214,150,1)', 'rgba(255,190,110,0)'));
    W.butterflies = [];
    for (let i = 0; i < 7; i++) {
      const b = new THREE.Group();
      const bodyMat = new THREE.MeshStandardMaterial({ color: 0x8a6b46, roughness: 0.6, transparent: true, opacity: 0, emissive: 0x543c1c, emissiveIntensity: 0.6 });
      const wMat = new THREE.MeshBasicMaterial({
        map: wingTex, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false,
        color: 0xffe4b4, fog: false,
      });
      const bod = new THREE.Mesh(new THREE.CapsuleGeometry(0.0026, 0.016, 4, 8), bodyMat);
      bod.rotation.x = Math.PI / 2;
      b.add(bod);
      const wgL = new THREE.Mesh(new THREE.PlaneGeometry(0.05, 0.05), wMat);
      wgL.geometry.translate(-0.025, 0, 0);
      wgL.rotation.z = 0;
      const wgR = wgL.clone();
      wgR.scale.x = -1;
      b.add(wgL, wgR);
      const glow = new THREE.Sprite(new THREE.SpriteMaterial({
        map: glowTex, transparent: true, opacity: 0, color: 0xffcf8e,
        blending: THREE.AdditiveBlending, depthWrite: false, fog: false,
      }));
      glow.scale.setScalar(0.17);
      b.add(glow);
      b.visible = false;
      b.userData = {
        seed: Math.random() * 100,
        center: new THREE.Vector3(rnd(-0.7, 0.7), rnd(0.95, 1.5), rnd(-0.3, 0.6)),
        rx: rnd(0.25, 0.6), rz: rnd(0.2, 0.5), spd: rnd(0.25, 0.5) * (Math.random() < 0.5 ? 1 : -1),
        mats: [bodyMat, wMat, glow.material],
        wings: [wgL, wgR],
      };
      scene.add(b);
      W.butterflies.push(b);
    }

    // petals — small curled slips of blush and cream
    const petalGeo = new THREE.PlaneGeometry(0.011, 0.017, 1, 2);
    {
      const pp = petalGeo.attributes.position;
      for (let i = 0; i < pp.count; i++) {
        const y = pp.getY(i);
        if (Math.abs(y) < 0.006) pp.setZ(i, 0.0045);
        else pp.setX(i, pp.getX(i) * 0.55); // taper the ends
      }
      petalGeo.computeVertexNormals();
    }
    const petalMat = new THREE.MeshStandardMaterial({
      color: 0xffffff, roughness: 0.9, side: THREE.DoubleSide, transparent: true, opacity: 0.92,
    });
    const PETALS = 30;
    const petals = new THREE.InstancedMesh(petalGeo, petalMat, PETALS);
    petals.visible = false;
    petals.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    W.petalState = [];
    for (let i = 0; i < PETALS; i++) {
      W.petalState.push({
        p: new THREE.Vector3(rnd(-0.9, 0.9), rnd(1.3, 2.4), rnd(-0.4, 0.8)),
        phase: Math.random() * 10, spin: rnd(0.8, 2.2), fall: rnd(0.07, 0.13), delay: rnd(0, 7),
      });
      petals.setColorAt(i, new THREE.Color().setHSL(rnd(0.02, 0.07), rnd(0.18, 0.32), rnd(0.78, 0.88)));
    }
    scene.add(petals);
    W.petals = petals;

    // rising sparkles
    const spkN = 130;
    const spkPos = new Float32Array(spkN * 3);
    const spkSeed = new Float32Array(spkN);
    for (let i = 0; i < spkN; i++) {
      spkPos[i * 3] = rnd(-1.2, 1.2);
      spkPos[i * 3 + 1] = rnd(0.75, 2.4);
      spkPos[i * 3 + 2] = rnd(-0.7, 1.0);
      spkSeed[i] = Math.random() * 100;
    }
    const spkGeo = new THREE.BufferGeometry();
    spkGeo.setAttribute('position', new THREE.BufferAttribute(spkPos, 3));
    spkGeo.setAttribute('aSeed', new THREE.BufferAttribute(spkSeed, 1));
    const spkMat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: {
        uTime: { value: 0 }, uAlpha: { value: 0 },
        uSize: { value: 5.5 * Math.min(devicePixelRatio, 2) },
        uColor: { value: new THREE.Color(0xffd98e) },
      },
      vertexShader: `
        attribute float aSeed; uniform float uTime; uniform float uSize;
        varying float vTw;
        void main(){
          vec3 p = position;
          p.y = 0.75 + mod(position.y - 0.75 + uTime*(0.06+fract(aSeed*0.37)*0.07), 1.9);
          p.x += sin(uTime*0.5+aSeed)*0.05;
          p.z += cos(uTime*0.4+aSeed*1.3)*0.05;
          vec4 mv = modelViewMatrix*vec4(p,1.0);
          gl_PointSize = uSize*(1.0/-mv.z)*(0.5+0.5*fract(aSeed*0.71));
          vTw = 0.3+0.7*pow(0.5+0.5*sin(uTime*(2.0+fract(aSeed)*2.0)+aSeed*9.0), 2.0);
          gl_Position = projectionMatrix*mv;
        }`,
      fragmentShader: `
        uniform vec3 uColor; uniform float uAlpha;
        varying float vTw;
        void main(){
          vec2 d = gl_PointCoord-0.5;
          float m = smoothstep(0.5,0.06,length(d));
          gl_FragColor = vec4(uColor, m*vTw*uAlpha);
        }`,
    });
    const sparkles = new THREE.Points(spkGeo, spkMat);
    sparkles.frustumCulled = false;
    scene.add(sparkles);
    W.sparkleMat = spkMat;

    return W;
  }

  W.build = build;
  return W;
})();
