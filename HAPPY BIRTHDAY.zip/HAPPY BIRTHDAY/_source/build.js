﻿// Assembles the single-file experience: fonts + css + three.js + app code.
const fs = require('fs');
const path = require('path');

const SP = __dirname;
const OUT_DIR = path.join(__dirname, '..');

const read = (p) => fs.readFileSync(path.join(SP, p), 'utf8');

const three = read('vendor/three.min.js');
const css = read('src/style.css');
const body = read('src/body.html');
const audio = read('src/audio.js');
const world = read('src/world.js');
const app = read('src/app.js');

const f = (name) => fs.readFileSync(path.join(SP, 'fonts', name), 'utf8').trim();
const fontsCSS = `
@font-face{font-family:'Great Vibes';font-style:normal;font-weight:400;font-display:swap;src:url(data:font/woff2;base64,${f('greatvibes.b64')}) format('woff2');}
@font-face{font-family:'EB Garamond';font-style:normal;font-weight:500;font-display:swap;src:url(data:font/woff2;base64,${f('garamond.b64')}) format('woff2');}
@font-face{font-family:'EB Garamond';font-style:italic;font-weight:500;font-display:swap;src:url(data:font/woff2;base64,${f('garamond-italic.b64')}) format('woff2');}
`;

const configBlock = `<script>
/* ============================================================================
   вњЏпёЏ  EDIT YOUR MESSAGE HERE вЂ” this is the only part you ever need to touch.
   Change any text between the quotes. Keep the commas. Save, then reopen
   the file in a browser. Emoji are fine.
   ============================================================================ */
window.CONFIG = {

  // --- title screen ---
  titleEyebrow: "Something small arrived for you",
  title:        "For You",
  titleSub:     "a birthday letter",
  beginButton:  "Begin",
  beginNote:    "sound on, lights low",

  // --- their birthday (shown on the title screen and at the top of the letter) ---
  birthdayDate: "25.10.2026",

  // --- the one button on the desk ---
  openButton:   "Open the letter",

  // --- the letter itself ---
  headline: "Happy Birthday!",
  paragraphs: [
    "Today isn't just another birthday.",
    "Today marks the beginning of a beautiful new chapter.",
    "May every dream you chase find its way to you.",
    "May every challenge shape you into someone even stronger.",
    "May happiness follow every step you take.",
    "Never stop believing in yourself.",
    "Never stop smiling.",
    "And never forget how special you truly are.",
    "Happy Birthday.",
  ],
  signature: "With all my heart",
  fromName:  "Zyrex",          // your name, signed under the letter. Set to "" to hide it.

  // --- reading voice (reads the letter aloud as it is written) ---
  // Always English. It will never use a Russian or other-language voice:
  // if the device has no English voice it simply stays quiet.
  voice:       true,           // set to false for no narration at all
  voiceLang:   "en-GB",        // "en-GB" (softer) or "en-US"
  voiceName:   "Google UK English Female",  // "" = pick the best English one automatically
  voiceRate:   0.76,           // lower = slower and gentler (0.70 - 0.90)
  voicePitch:  0.96,           // lower = warmer, higher = brighter (0.90 - 1.10)
  voiceVolume: 0.70,           // lower = softer, more intimate (0.50 - 1.00)

  // Want a different voice? Open the page, press F12, and type:
  //     listVoices()                    -> lists your English voices
  //     tryVoice("Google US English")   -> hear it read a line
  // Then paste the name you like into voiceName above.
  // For an even softer read, try:  voiceRate: 0.72, voiceVolume: 0.55

  // --- final card ---
  endEyebrow:   "And always remember",
  endTitle:     "Happy Birthday",
  endLine:      "with all my heart",
  replayButton: "Watch it again",

  // --- your credit at the very end ---
  creditText: "Created by Zyrex",
  creditLink: "https://t.me/muhammadamin_baxodirov",
};
/* ======================= end of editable text ============================ */
</script>`;

const core = `${configBlock}
<style>${fontsCSS}\n${css}</style>
${body}
<script>${three}</script>
<script>
${audio}
${world}
${app}
</script>`;

const standalone = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>For You — a birthday letter</title>
</head>
<body>
${core}
</body>
</html>`;

fs.writeFileSync(path.join(OUT_DIR, 'Happy Birthday.html'), standalone);

// artifact flavor: no document skeleton, title tag inline
const artifact = `<title>For You — a birthday letter</title>\n${core}`;
fs.writeFileSync(path.join(SP, 'artifact.html'), artifact);

// web flavor: a folder ready to drop on Vercel / Netlify / any static host
const webDir = path.join(OUT_DIR, 'web');
fs.mkdirSync(webDir, { recursive: true });
const social = `<meta name="description" content="A letter, delivered by paper airplane.">
<meta name="theme-color" content="#1a1007">
<meta property="og:type" content="website">
<meta property="og:title" content="For You — a birthday letter">
<meta property="og:description" content="A letter, delivered by paper airplane.">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ctext y='26' font-size='26'%3E%F0%9F%92%8C%3C/text%3E%3C/svg%3E">
</head>`;
fs.writeFileSync(path.join(webDir, 'index.html'), standalone.replace('</head>', social));
fs.writeFileSync(path.join(webDir, 'vercel.json'), JSON.stringify({
  $schema: 'https://openapi.vercel.sh/vercel.json',
  headers: [{
    source: '/(.*)',
    headers: [{ key: 'Cache-Control', value: 'public, max-age=0, must-revalidate' }],
  }],
}, null, 2) + '\n');

const mb = (n) => (fs.statSync(n).size / 1024 / 1024).toFixed(2) + ' MB';
console.log('standalone:', mb(path.join(OUT_DIR, 'Happy Birthday.html')));
console.log('artifact:  ', mb(path.join(SP, 'artifact.html')));
console.log('web/:      ', mb(path.join(webDir, 'index.html')), '- ready to deploy');

